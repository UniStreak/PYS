﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace FileIO
{

    public sealed class BinaryFileIO<TDictKey, TDictVal> : FileIOBase, IFileAccess<TDictKey, TDictVal>
    {
        const string INVALID_ARGUMENT = "Default root or namespace is invalid",
            ALREADY_OPEN = "{0} is already open",
            ALREADY_CLOSED = "{0} is already closed",
            NOT_OPEN = "{0} is not open";


        public SortedDictionary<TDictKey, TDictVal> Database { get; set; }

        public BinaryFormatter Serializer { get; }

        public bool IsOpen { get; internal set; }



        public BinaryFileIO(string fileName)
            : base(fileName)
        {
            Serializer = new BinaryFormatter();
        }

        public BinaryFileIO(string fileName, FileAccess accessMode)
            : this(fileName)
        {
            AccessMode = accessMode;
        }

        public BinaryFileIO(string fileName, SortedDictionary<TDictKey, TDictVal> database, FileAccess accessMode)
            : this(fileName)
        {
            Database = database;
            AccessMode = accessMode;
        }


        public void OpenFileDB()
        {
            if (string.IsNullOrEmpty(FileInfo.FullName) || IsOpen)
                throw new FileStatusException(string.Format(ALREADY_OPEN, FileInfo.Name), FileInfo.FullName);
            Stream = new FileStream(FileInfo.FullName, FileMode.OpenOrCreate, AccessMode);
            IsOpen = true;
        }

        public void CloseFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(ALREADY_CLOSED, FileInfo.Name), FileInfo.FullName);
            Stream.Close();
            IsOpen = false;
        }

        public void ReadFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(NOT_OPEN, FileInfo.Name), FileInfo.FullName);
            Database = (SortedDictionary<TDictKey, TDictVal>)Serializer.Deserialize(Stream);
        }

        public void WriteFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(NOT_OPEN, FileInfo.Name), FileInfo.FullName);
            Serializer.Serialize(Stream, Database);
        }
    }
}

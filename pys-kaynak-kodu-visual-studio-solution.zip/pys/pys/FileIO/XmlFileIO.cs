﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Runtime.Serialization;

namespace FileIO
{

    public sealed class XmlFileIO<TDictKey, TDictVal> : FileIOBase, IFileAccess<TDictKey, TDictVal>
    {
        const string INVALID_ARGUMENT = "Varsayılan kök veya ad alanı geçersiz",
            ALREADY_OPEN = "{0} zaten açık ya da geçersiz",
            ALREADY_CLOSED = "{0} zaten kapalı",
            NOT_OPEN = "{0} açık değil";
        XmlWriter writer;
        XmlReader reader;

        public SortedDictionary<TDictKey, TDictVal> Database { get; set; }

        public DataContractSerializer Serializer { get; }

        public bool IsOpen { get; internal set; }

        public FileMode FileMode { get; }



        public XmlFileIO(string fileName)
            : base(fileName)
        {
            Serializer = new DataContractSerializer(typeof(SortedDictionary<TDictKey, TDictVal>));
            FileMode = FileMode.OpenOrCreate;
        }

        public XmlFileIO(string fileName, SortedDictionary<TDictKey, TDictVal> database)
            : base(fileName)
        {
            Database = database;
            Serializer = new DataContractSerializer(typeof(SortedDictionary<TDictKey, TDictVal>));
            FileMode = FileMode.OpenOrCreate;
        }

        public XmlFileIO(string fileName, FileMode fileMode, SortedDictionary<TDictKey, TDictVal> database)
            : base(fileName)
        {
            Database = database;
            Serializer = new DataContractSerializer(typeof(SortedDictionary<TDictKey, TDictVal>));
            FileMode = fileMode;
        }

        public XmlFileIO(string fileName, string rootName, string rootNamespace)
            : base(fileName)
        {
            if (string.IsNullOrEmpty(rootName) || string.IsNullOrEmpty(rootNamespace))
                throw new ArgumentException(INVALID_ARGUMENT);
            Serializer = new DataContractSerializer(typeof(SortedDictionary<TDictKey,TDictVal>), rootName, rootNamespace);
            FileMode = FileMode.OpenOrCreate;
        }

        public XmlFileIO(string fileName, SortedDictionary<TDictKey, TDictVal> database, string rootName, string rootNamespace)
            : this(fileName, rootName, rootNamespace)
        {
            Database = database;
            FileMode = FileMode.OpenOrCreate;
        }

        public XmlFileIO(string fileName, FileMode fileMode, SortedDictionary<TDictKey, TDictVal> database, string rootName, string rootNamespace)
            : this(fileName, rootName, rootNamespace)
        {
            Database = database;
            FileMode = fileMode;
        }


        public void OpenFileDB()
        {
            if (string.IsNullOrEmpty(FileInfo.FullName) || IsOpen)
                throw new FileStatusException(string.Format(ALREADY_OPEN, FileInfo.Name), FileInfo.FullName);
            Stream = new FileStream(FileInfo.FullName, FileMode, AccessMode);
            IsOpen = true;
        }

        public void CloseFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(ALREADY_CLOSED, FileInfo.Name), FileInfo.FullName);
            Stream.Close();
            IsOpen = false;
        }

        public void ReadFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(NOT_OPEN, FileInfo.Name), FileInfo.FullName);
            using (reader = XmlReader.Create(Stream))
            {
                Database = (SortedDictionary<TDictKey,TDictVal>)Serializer.ReadObject(reader);
            }
        }

        public void WriteFileDB()
        {
            if (!IsOpen)
                throw new FileStatusException(string.Format(NOT_OPEN, FileInfo.Name), FileInfo.FullName);
            XmlWriterSettings settings = new XmlWriterSettings() { Indent = true };
            using (writer = XmlWriter.Create(Stream, settings))
            {
                Serializer.WriteObject(writer, Database);
            }
        }
    }
}

﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Windows.Forms;

namespace pys
{
    public partial class Ayarlar : Form
    {
        public Ayarlar()
        {
            InitializeComponent();
            textBox_DByolu.Text = Properties.Settings.Default.DB_Yolu;
        }

        private void Buton_GozatDByolu_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    textBox_DByolu.Text = dialog.FileName;
                }
            }
        }

        private void Buton_ayariptal_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void Buton_ayarkaydet_Click(object sender, EventArgs e)
        {
            
            if (Properties.Settings.Default.DB_Yolu != textBox_DByolu.Text)
            {
                Properties.Settings.Default.DB_Yolu = textBox_DByolu.Text;
            }            
            Properties.Settings.Default.Save();
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}

﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class Kayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kayit));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_soyadi = new System.Windows.Forms.TextBox();
            this.secbuton = new System.Windows.Forms.Button();
            this.resimyolu = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_telefon = new System.Windows.Forms.TextBox();
            this.txt_adres = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_adi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_tc = new System.Windows.Forms.TextBox();
            this.txt_departman = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_cikist = new System.Windows.Forms.DateTimePicker();
            this.txt_girist = new System.Windows.Forms.DateTimePicker();
            this.txt_kangrubu = new System.Windows.Forms.ComboBox();
            this.txt_mhali = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_pozisyon = new System.Windows.Forms.TextBox();
            this.txt_ekbilgi = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_cocuksayisi = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Buton_kaydet = new System.Windows.Forms.Button();
            this.Buton_iptal = new System.Windows.Forms.Button();
            this.errProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txt_soyadi);
            this.groupBox1.Controls.Add(this.secbuton);
            this.groupBox1.Controls.Add(this.resimyolu);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_telefon);
            this.groupBox1.Controls.Add(this.txt_adres);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.txt_adi);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_tc);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(778, 150);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personel Bilgileri";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label15.Location = new System.Drawing.Point(49, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 19);
            this.label15.TabIndex = 23;
            this.label15.Text = "Soyadı";
            // 
            // txt_soyadi
            // 
            this.txt_soyadi.Location = new System.Drawing.Point(104, 83);
            this.txt_soyadi.MaxLength = 30;
            this.txt_soyadi.Name = "txt_soyadi";
            this.txt_soyadi.Size = new System.Drawing.Size(182, 22);
            this.txt_soyadi.TabIndex = 3;
            // 
            // secbuton
            // 
            this.secbuton.Location = new System.Drawing.Point(575, 109);
            this.secbuton.Name = "secbuton";
            this.secbuton.Size = new System.Drawing.Size(45, 23);
            this.secbuton.TabIndex = 21;
            this.secbuton.Text = "Seç";
            this.secbuton.UseVisualStyleBackColor = true;
            this.secbuton.Click += new System.EventHandler(this.secbuton_Click);
            // 
            // resimyolu
            // 
            this.resimyolu.Enabled = false;
            this.resimyolu.Location = new System.Drawing.Point(376, 110);
            this.resimyolu.MaxLength = 100;
            this.resimyolu.Name = "resimyolu";
            this.resimyolu.Size = new System.Drawing.Size(193, 22);
            this.resimyolu.TabIndex = 20;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(626, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label7.Location = new System.Drawing.Point(309, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 19);
            this.label7.TabIndex = 18;
            this.label7.Text = "Fotoğraf";
            // 
            // txt_telefon
            // 
            this.txt_telefon.Location = new System.Drawing.Point(104, 110);
            this.txt_telefon.MaxLength = 20;
            this.txt_telefon.Name = "txt_telefon";
            this.txt_telefon.Size = new System.Drawing.Size(182, 22);
            this.txt_telefon.TabIndex = 4;
            // 
            // txt_adres
            // 
            this.txt_adres.Location = new System.Drawing.Point(376, 56);
            this.txt_adres.MaxLength = 100;
            this.txt_adres.Multiline = true;
            this.txt_adres.Name = "txt_adres";
            this.txt_adres.Size = new System.Drawing.Size(244, 48);
            this.txt_adres.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label14.Location = new System.Drawing.Point(347, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 19);
            this.label14.TabIndex = 17;
            this.label14.Text = "ID";
            // 
            // txt_id
            // 
            this.txt_id.Enabled = false;
            this.txt_id.Location = new System.Drawing.Point(376, 29);
            this.txt_id.MaxLength = 10;
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(121, 22);
            this.txt_id.TabIndex = 12;
            // 
            // txt_adi
            // 
            this.txt_adi.Location = new System.Drawing.Point(104, 56);
            this.txt_adi.MaxLength = 30;
            this.txt_adi.Name = "txt_adi";
            this.txt_adi.Size = new System.Drawing.Size(182, 22);
            this.txt_adi.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(12, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "TC Kimlik No";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label8.Location = new System.Drawing.Point(46, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "Telefon";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(326, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adres";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label3.Location = new System.Drawing.Point(69, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adı";
            // 
            // txt_tc
            // 
            this.txt_tc.Location = new System.Drawing.Point(104, 29);
            this.txt_tc.MaxLength = 11;
            this.txt_tc.Name = "txt_tc";
            this.txt_tc.Size = new System.Drawing.Size(182, 22);
            this.txt_tc.TabIndex = 1;
            // 
            // txt_departman
            // 
            this.txt_departman.Location = new System.Drawing.Point(104, 34);
            this.txt_departman.MaxLength = 20;
            this.txt_departman.Name = "txt_departman";
            this.txt_departman.Size = new System.Drawing.Size(146, 22);
            this.txt_departman.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label5.Location = new System.Drawing.Point(20, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Departman";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_cikist);
            this.groupBox2.Controls.Add(this.txt_girist);
            this.groupBox2.Controls.Add(this.txt_kangrubu);
            this.groupBox2.Controls.Add(this.txt_mhali);
            this.groupBox2.Controls.Add(this.txt_departman);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_pozisyon);
            this.groupBox2.Controls.Add(this.txt_ekbilgi);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txt_cocuksayisi);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 168);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(778, 163);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Detaylar";
            // 
            // txt_cikist
            // 
            this.txt_cikist.Checked = false;
            this.txt_cikist.CustomFormat = "";
            this.txt_cikist.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_cikist.Location = new System.Drawing.Point(357, 61);
            this.txt_cikist.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.txt_cikist.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_cikist.Name = "txt_cikist";
            this.txt_cikist.ShowCheckBox = true;
            this.txt_cikist.Size = new System.Drawing.Size(212, 22);
            this.txt_cikist.TabIndex = 10;
            this.txt_cikist.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // txt_girist
            // 
            this.txt_girist.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_girist.Location = new System.Drawing.Point(357, 34);
            this.txt_girist.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.txt_girist.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.txt_girist.Name = "txt_girist";
            this.txt_girist.Size = new System.Drawing.Size(212, 22);
            this.txt_girist.TabIndex = 9;
            this.txt_girist.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // txt_kangrubu
            // 
            this.txt_kangrubu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_kangrubu.FormattingEnabled = true;
            this.txt_kangrubu.Items.AddRange(new object[] {
            "0-",
            "0+",
            "A-",
            "A+",
            "B-",
            "B+",
            "AB-",
            "AB+"});
            this.txt_kangrubu.Location = new System.Drawing.Point(104, 88);
            this.txt_kangrubu.Name = "txt_kangrubu";
            this.txt_kangrubu.Size = new System.Drawing.Size(146, 21);
            this.txt_kangrubu.TabIndex = 8;
            // 
            // txt_mhali
            // 
            this.txt_mhali.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_mhali.FormattingEnabled = true;
            this.txt_mhali.Items.AddRange(new object[] {
            "Evli",
            "Bekar"});
            this.txt_mhali.Location = new System.Drawing.Point(673, 32);
            this.txt_mhali.Name = "txt_mhali";
            this.txt_mhali.Size = new System.Drawing.Size(94, 21);
            this.txt_mhali.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label6.Location = new System.Drawing.Point(23, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 19);
            this.label6.TabIndex = 19;
            this.label6.Text = "Kan Grubu";
            // 
            // txt_pozisyon
            // 
            this.txt_pozisyon.Location = new System.Drawing.Point(104, 61);
            this.txt_pozisyon.MaxLength = 30;
            this.txt_pozisyon.Name = "txt_pozisyon";
            this.txt_pozisyon.Size = new System.Drawing.Size(146, 22);
            this.txt_pozisyon.TabIndex = 7;
            // 
            // txt_ekbilgi
            // 
            this.txt_ekbilgi.Location = new System.Drawing.Point(357, 91);
            this.txt_ekbilgi.MaxLength = 200;
            this.txt_ekbilgi.Multiline = true;
            this.txt_ekbilgi.Name = "txt_ekbilgi";
            this.txt_ekbilgi.Size = new System.Drawing.Size(410, 55);
            this.txt_ekbilgi.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label13.Location = new System.Drawing.Point(299, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 19);
            this.label13.TabIndex = 16;
            this.label13.Text = "Ek Bilgi";
            // 
            // txt_cocuksayisi
            // 
            this.txt_cocuksayisi.Location = new System.Drawing.Point(673, 61);
            this.txt_cocuksayisi.MaxLength = 3;
            this.txt_cocuksayisi.Name = "txt_cocuksayisi";
            this.txt_cocuksayisi.Size = new System.Drawing.Size(94, 22);
            this.txt_cocuksayisi.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label12.Location = new System.Drawing.Point(583, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 19);
            this.label12.TabIndex = 12;
            this.label12.Text = "Çocuk Sayısı";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label11.Location = new System.Drawing.Point(279, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 19);
            this.label11.TabIndex = 11;
            this.label11.Text = "Çıkış Tarihi";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label10.Location = new System.Drawing.Point(585, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "Medeni Hali";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label9.Location = new System.Drawing.Point(280, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 19);
            this.label9.TabIndex = 9;
            this.label9.Text = "Giriş Tarihi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(36, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pozisyon";
            // 
            // Buton_kaydet
            // 
            this.Buton_kaydet.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_kaydet.Location = new System.Drawing.Point(574, 337);
            this.Buton_kaydet.Name = "Buton_kaydet";
            this.Buton_kaydet.Size = new System.Drawing.Size(105, 35);
            this.Buton_kaydet.TabIndex = 14;
            this.Buton_kaydet.Text = "Kaydet";
            this.Buton_kaydet.UseVisualStyleBackColor = true;
            this.Buton_kaydet.Click += new System.EventHandler(this.Buton_kaydet_Click);
            // 
            // Buton_iptal
            // 
            this.Buton_iptal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_iptal.Location = new System.Drawing.Point(685, 337);
            this.Buton_iptal.Name = "Buton_iptal";
            this.Buton_iptal.Size = new System.Drawing.Size(105, 35);
            this.Buton_iptal.TabIndex = 15;
            this.Buton_iptal.Text = "İptal";
            this.Buton_iptal.UseVisualStyleBackColor = true;
            this.Buton_iptal.Click += new System.EventHandler(this.Buton_iptal_Click);
            // 
            // errProvider
            // 
            this.errProvider.ContainerControl = this;
            // 
            // Kayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 380);
            this.Controls.Add(this.Buton_iptal);
            this.Controls.Add(this.Buton_kaydet);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Kayit";
            this.Text = "Personel Yönetim Sistemi Kayıt Ekranı";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Buton_kaydet;
        private System.Windows.Forms.Button Buton_iptal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_tc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_telefon;
        private System.Windows.Forms.TextBox txt_departman;
        private System.Windows.Forms.TextBox txt_adres;
        private System.Windows.Forms.TextBox txt_adi;
        private System.Windows.Forms.TextBox txt_ekbilgi;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_cocuksayisi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_pozisyon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button secbuton;
        private System.Windows.Forms.TextBox resimyolu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox txt_mhali;
        private System.Windows.Forms.ComboBox txt_kangrubu;
        private System.Windows.Forms.DateTimePicker txt_girist;
        private System.Windows.Forms.DateTimePicker txt_cikist;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_soyadi;
        private System.Windows.Forms.ErrorProvider errProvider;
    }
}
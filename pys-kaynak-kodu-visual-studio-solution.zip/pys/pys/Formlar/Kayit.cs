﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Windows.Forms;
using pys.Personel;
using pys.Diger;

namespace pys
{
    public partial class Kayit : Form
    {
        int calisanID;
        public Calisan _Calisan { get; private set; }
        public Kayit(int id)
        {
            InitializeComponent();
            calisanID = id;
            txt_id.Text = $"{calisanID:D7}";
            errProvider.Icon = Properties.Resources.blackX;
        }

        public Kayit(Calisan calisan)
        {
            InitializeComponent();
            _Calisan = calisan;
            calisanID = _Calisan.CalisanID;
            txt_id.Text = $"{calisanID:D7}";
            errProvider.Icon = Properties.Resources.blackX;
            FormDoldur();
        }

        #region Yardımcı Fonksiyonlar

        private bool CheckIfEmpty(Control control)
        {
            if (string.IsNullOrEmpty(control.Text))
            {
                errProvider.SetError(control, "Zorunlu alan");
                return true;
            }
            else
            {
                errProvider.SetError(control, string.Empty);
                return false;
            }
        }

        private bool FormIsFilled(Control[] controls)
        {
            foreach (var control in controls)
            {
                if (CheckIfEmpty(control))
                    return false;
            }
            return true;
        }
        #endregion

        private void Buton_kaydet_Click(object sender, EventArgs e)
        {
            Control[] controls = new Control[]
            {
                txt_tc,
                txt_adi,
                txt_soyadi,
                txt_telefon,
                txt_girist,
                txt_departman,
                txt_pozisyon
            };
            
            if (!FormIsFilled(controls))
            {
                MessageBox.Show(Strings.Errors.FORM_NOT_FILLED, Strings.Errors.ERROR_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CalisanKayit _calisanKayit = GetCalisanKayit();

            try
            {
                _Calisan = GetCalisan(_calisanKayit);
            }

            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message,
                Strings.Errors.ERROR_TITLE,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
                return;
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void Buton_iptal_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private CalisanKayit GetCalisanKayit()
        {
            CalisanKayit _calisankayit;
            _calisankayit = new CalisanKayit(txt_tc.Text, txt_adi.Text, txt_soyadi.Text, txt_telefon.Text, txt_adres.Text, txt_departman.Text, txt_pozisyon.Text, txt_girist.Text, txt_cikist.Checked,
                txt_cikist.Text, txt_mhali.Text, txt_cocuksayisi.Text, txt_kangrubu.Text, txt_ekbilgi.Text, resimyolu.Text);
            return _calisankayit;
        }

        private Calisan GetCalisan(CalisanKayit calisanKaydi)
        {
            if (CheckIfEmpty(txt_id) || !int.TryParse(txt_id.Text, out calisanID))
            {
                MessageBox.Show(Strings.Errors.INVALID_FORM_DATA, Strings.Errors.ERROR_TITLE);
                return null;
            }
            return new CalisanNesne(calisanKaydi, calisanID);
        }

        private void FormDoldur()
        {
            if (_Calisan == null)
                return;
            txt_id.Text = $"{_Calisan.CalisanID:D7}";
            txt_tc.Text = _Calisan._CalisanKayit.TC_Kimlik;
            txt_adi.Text = _Calisan._CalisanKayit.Adi;
            txt_soyadi.Text = _Calisan._CalisanKayit.Soyadi;
            txt_telefon.Text = _Calisan._CalisanKayit.Telefon;
            txt_adres.Text = _Calisan._CalisanKayit.Adres;
            txt_departman.Text = _Calisan._CalisanKayit.Departman;
            txt_pozisyon.Text = _Calisan._CalisanKayit.Pozisyon;
            txt_girist.Text = _Calisan._CalisanKayit.GirisT;
            txt_cikist.Checked = _Calisan._CalisanKayit.CikisTCheck;
            if (txt_cikist.Checked==true)
                txt_cikist.Text = _Calisan._CalisanKayit.CikisT;
            txt_mhali.Text = _Calisan._CalisanKayit.MedeniHali;
            txt_cocuksayisi.Text = _Calisan._CalisanKayit.CocukSayisi;
            txt_kangrubu.Text = _Calisan._CalisanKayit.KanGrubu;
            txt_ekbilgi.Text = _Calisan._CalisanKayit.EkBilgi;
            resimyolu.Text = _Calisan._CalisanKayit.FotoYolu;
            pictureBox1.ImageLocation = _Calisan._CalisanKayit.FotoYolu;
        }

        private void secbuton_Click(object sender, EventArgs e)
        {
            OpenFileDialog dosya = new OpenFileDialog();
            dosya.Filter = "Resim Dosyası |*.jpg;*.png |  Tüm Dosyalar |*.*";
            if (dosya.ShowDialog() != DialogResult.Cancel)
            {
                string dosyayolu = dosya.FileName;
                string hedefyolu = @".\personel-img\";
                bool dizin = System.IO.Directory.Exists(hedefyolu);
                if (dizin == false)
                    System.IO.Directory.CreateDirectory(hedefyolu);
                string hedefdosya = "personel " + Guid.NewGuid() + ".jpg";
                System.IO.File.Copy(dosyayolu, hedefyolu + hedefdosya, true);
                resimyolu.Text = hedefyolu + hedefdosya;
                pictureBox1.ImageLocation = hedefyolu + hedefdosya;
            }
        }
    }
}

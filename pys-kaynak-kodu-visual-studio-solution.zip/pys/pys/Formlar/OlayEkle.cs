﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Windows.Forms;
using pys.Personel;

namespace pys
{
    public partial class OlayEkle : Form
    {
        public Olay _Olay { get; set; }

        public OlayEkle()
        {
            InitializeComponent();
            errProvider.Icon = Properties.Resources.blackX;
        }

        public OlayEkle(Olay eOlay)
        {
            InitializeComponent();
            errProvider.Icon = Properties.Resources.blackX;
            FormDoldur(eOlay);
        }

        private void Buton_iptal_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void Buton_olaykaydet_Click(object sender, EventArgs e)
        {
            Control[] controls = new Control[]
            {
                olayID,
                olayadi,
                olayaciklamasi
            };
            foreach (Control control in controls)
                CheckIfEmpty(control);
            _Olay = new Olay(olayID.Text, olayadi.Text, olayaciklamasi.Text, baslangictarihi.Text, bitistarihi.Text, baslangicsaati.Text, bitissaati.Text, baslangictarihi.Checked,
                bitistarihi.Checked, baslangicsaati.Checked, bitissaati.Checked);
            DialogResult = DialogResult.OK;
            Close();
        }

        #region Yardımcı Fonksiyonlar
        private void CheckIfEmpty(Control control)
        {
            if (string.IsNullOrEmpty(control.Text))
                errProvider.SetError(control, "Zorunlu alan");
            else
                errProvider.SetError(control, string.Empty);
        }

        private void FormDoldur(Olay olay)
        {
            olayID.Text = olay.OlayID;
            olayID.Enabled = false;
            olayadi.Text = olay.OlayAdi;
            olayaciklamasi.Text = olay.OlayAciklamasi;
            baslangictarihi.Checked = olay.BaslangicTarihiCheck;
            bitistarihi.Checked = olay.BitisTarihiCheck;
            baslangicsaati.Checked = olay.BaslangicSaatiCheck;
            bitissaati.Checked = olay.BitisTarihiCheck;
            if (baslangictarihi.Checked == true)
                baslangictarihi.Text = olay.BaslangicTarihi;
            if (bitistarihi.Checked == true)
                bitistarihi.Text = olay.BitisTarihi;
            if (baslangicsaati.Checked == true)
                baslangicsaati.Text = olay.BaslangicSaati;
            if (bitissaati.Checked == true)
                bitissaati.Text = olay.BitisSaati;
        }
        #endregion
    }
}

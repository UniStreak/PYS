﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------
using System.Runtime.Serialization;

namespace pys.Personel
{
    [DataContract(Name = "Personal_Information")]
    public struct CalisanKayit
    {
        [DataMember] public string TC_Kimlik { get; set; }
        [DataMember] public string Adi { get; set; }
        [DataMember] public string Soyadi { get; set; }
        [DataMember] public string Telefon { get; set; }
        [DataMember] public string Adres { get; set; }
        [DataMember] public string Departman { get; set; }
        [DataMember] public string Pozisyon { get; set; }
        [DataMember] public string GirisT { get; set; }
        [DataMember] public bool CikisTCheck { get; set; }
        [DataMember] public string CikisT { get; set; }
        [DataMember] public string MedeniHali { get; set; }
        [DataMember] public string CocukSayisi { get; set; }
        [DataMember] public string KanGrubu { get; set; }
        [DataMember] public string EkBilgi { get; set; }
        [DataMember] public string FotoYolu { get; set; }

        public CalisanKayit(string _tc, string _adi, string _soyadi, string _telefon, string _adres, string _departman, string _pozisyon, string _girist,
            bool _cikistcheck, string _cikist, string _mhali, string _cocuks, string _kangrubu, string _ekbilgi, string _fotoyolu)
        {
            TC_Kimlik = _tc;
            Adi = _adi;
            Soyadi = _soyadi;
            Telefon = _telefon;
            Adres = _adres;
            Departman = _departman;
            Pozisyon = _pozisyon;
            GirisT = _girist;
            CikisTCheck = _cikistcheck;
            CikisT = _cikist;
            MedeniHali = _mhali;
            CocukSayisi = _cocuks;
            KanGrubu = _kangrubu;
            EkBilgi = _ekbilgi;
            FotoYolu = _fotoyolu;
        }

    }
}

﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------
using System.Runtime.Serialization;

namespace pys.Personel
{
    [DataContract]
    public class CalisanNesne : Calisan
    {
        public CalisanNesne(CalisanKayit _calisanKayit, int _id)
            : base(_calisanKayit, _id)
        {

        }
    }
}
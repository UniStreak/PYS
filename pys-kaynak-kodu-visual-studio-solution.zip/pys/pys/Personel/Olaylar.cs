﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System.Collections.Generic;
using System.Runtime.Serialization;

namespace pys.Personel
{
    [DataContract (Name = "Olaylar_")]
    public struct PersonelOlaylari
    {
        [DataMember] public SortedDictionary<string, Olay> Olaylar;
    }

    [DataContract]
    public struct Olay
    {
        [DataMember(Name = "OlayID", IsRequired = true)] public string OlayID { get; set; }
        [DataMember(Name = "OlayAdi", IsRequired = true)] public string OlayAdi { get; set; }
        [DataMember] public string OlayAciklamasi { get; set; }
        [DataMember] public string BaslangicTarihi { get; set; }
        [DataMember] public string BitisTarihi { get; set; }
        [DataMember] public string BaslangicSaati { get; set; }
        [DataMember] public string BitisSaati { get; set; }
        [DataMember] public bool BaslangicTarihiCheck { get; set; }
        [DataMember] public bool BitisTarihiCheck { get; set; }
        [DataMember] public bool BaslangicSaatiCheck { get; set; }
        [DataMember] public bool BitisSaatiCheck { get; set; }

        public Olay(string OlayID_, string OlayAdi_, string OlayAciklamasi_, string BaslangicTarihi_, string BitisTarihi_, string BaslangicSaati_, string BitisSaati_, 
            bool BaslangicTarihiCheck_, bool BitisTarihiCheck_, bool BaslangicSaatiCheck_, bool BitisSaatiCheck_)
        {
            OlayID = OlayID_;
            OlayAdi = OlayAdi_;
            OlayAciklamasi = OlayAciklamasi_;
            BaslangicTarihi = BaslangicTarihi_;
            BitisTarihi = BitisTarihi_;
            BaslangicSaati = BaslangicSaati_;
            BitisSaati = BitisSaati_;
            BaslangicTarihiCheck = BaslangicTarihiCheck_;
            BitisTarihiCheck = BitisTarihiCheck_;
            BaslangicSaatiCheck = BaslangicSaatiCheck_;
            BitisSaatiCheck = BitisSaatiCheck_;
        }
    }
}
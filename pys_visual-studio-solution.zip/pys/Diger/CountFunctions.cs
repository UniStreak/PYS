﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using pys.Personel;

namespace pys.Diger
{
    public static class CountFunctions
    {

        public static int CountVisible(this DBfunctions<uint, Calisan> database)
        {
            int count = 0;
            foreach (var emp in database.Database.Values)
            {
                if (emp.IsVisible)
                    count++;
            }
            return count;
        }

        public static int CountCalisan(this DBfunctions<uint, Calisan> database)
        {
            int count = 0;
            foreach (var emp in database.Database.Values)
            {
                if (emp.IsVisible && (!emp._CalisanKayit.CikisTCheck))
                    count++;
            }
            return count;
        }
    }
}
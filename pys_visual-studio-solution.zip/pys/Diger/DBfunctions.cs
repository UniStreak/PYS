﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Collections.Generic;

namespace pys.Diger
{
    public sealed class DBfunctions<TKey, TValue>
    {
        private SortedDictionary<TKey, TValue> database;

        public int Size
        {
            get
            {
                return database.Count;
            }
        }

        public SortedDictionary<TKey, TValue> Database
        {
            get
            {
                return database;
            }

            set
            {
                database = value;
            }
        }

        public DBfunctions()
        {
            database = new SortedDictionary<TKey, TValue>();
        }

        public TValue Retrieve(TKey key)
        {

            if (!database.ContainsKey(key))
                throw new ArgumentException(Strings.Errors.MISSING_KEY);

            return database[key];
        }

        public void Add(TKey key, TValue value)
        {

            if (database.ContainsKey(key))
                throw new ArgumentOutOfRangeException(Strings.Errors.INVALID_KEY);

            if (value == null)
                throw new ArgumentNullException(Strings.Errors.NULL_OBJECT_MESSAGE);

            database.Add(key, value);
        }

        public void Remove(TKey key)
        {

            if (!database.ContainsKey(key))
                throw new ArgumentException(Strings.Errors.INVALID_KEY);

            database.Remove(key);
        }
    }
}
﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys.Diger
{
    internal static class Strings
    {
        public struct Errors
        {
            public const string INFO_TITLE = "Bilgi";
            public const string ERROR_TITLE = "Hata";
            public const string INVALID_FILENAME = "Dosya adı geçersiz.";
            public const string INVALID_OBJECT = "Geçersiz obje argüman olarak iletildi.";
            public const string INVALID_FORM_DATA = "Form verileri geçersiz, lütfen form girişlerini kontrol edin.";
            public const string NO_RECORDS_SELECTED = "Bu işlem için hiçbir kayıt seçilmedi.";
            public const string FORM_NOT_FILLED = "Zorunlu alanlar doldurulmadı, lütfen girişleri doğrulayın.";
            public const string INVALID_KEY = "Lütfen geçerli bir anahtar girin.";
            public const string MISSING_KEY = "Veritabanı anahtar içermiyor.";
            public const string NULL_OBJECT_MESSAGE = "İletilen çalışan nesne boş olamaz.";
            public const string FIRST_TIME_USING = "Yeni veritabanı oluşturuldu.";
            public const string NOT_SELECTED = "Lütfen izin şablonu seçin.";
        }

        public struct Confirmation
        {
            public const string CONFIRM_TITLE = "İşlem Onayı";
            public const string CONFIRM_ACTION = "Emin misiniz?";
            public const string CONFIRM_SAVEDATABASE = "Mevcut veritabanını kaydetmek ister misiniz?";
        }

        public struct FileInfo
        {
            public const string FILE_FILTER = "Personel veritabanı dosyası (*.pysdb)|*.pysdb|Text files (*.txt)|*.txt|All files (*.*)|*.*";
            public const string DEFAULT_ROOT = "Database";
            public const string DEFAULT_NAMESPACE = "pys";
        }
    }
}
﻿using System;
using System.IO;

namespace FileIO
{

    public abstract class FileIOBase : IDisposable
    {

        public FileInfo FileInfo { get; }

        public FileAccess AccessMode { get; internal set; }

        public Stream Stream { get; internal set; }
        
        public FileIOBase(string fileName)
        {
            if (File.Exists(fileName))
                FileInfo = new FileInfo(fileName);
            else
                throw new FileNotFoundException($"{fileName} is not valid", fileName);
            
            AccessMode = FileAccess.ReadWrite;
        }

        public FileIOBase(string fileName, Stream stream)
            : this(fileName)
        {
            Stream = stream;
        }

        public FileIOBase(string fileName, FileAccess accessMode)
            : this(fileName)
        {
            AccessMode = accessMode;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Stream.Dispose();
            }
        }
    }
}

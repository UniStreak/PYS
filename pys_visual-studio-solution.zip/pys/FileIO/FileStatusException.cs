﻿using System;
using System.IO;

namespace FileIO
{
    [Serializable]
    public class FileStatusException : IOException
    {

        public FileAccess AccessMode;

        public FileInfo FileInfo;

        public FileStatusException() : base("File cannot be accessed, invalid FileAccess mode.") { }

        public FileStatusException(string message) : base(message) { }

        public FileStatusException(string message, Exception inner) : base(message, inner) { }

        public FileStatusException(string message, string fileName)
            : this(message)
        {
            FileInfo = new FileInfo(fileName);
        }

        public FileStatusException(string message, string fileName, Exception inner)
            : this(message, inner)
        {
            FileInfo = new FileInfo(fileName);
        }

        public FileStatusException(string message, string fileName, FileAccess accessMode)
            : this(message, fileName)
        {
            AccessMode = accessMode;
        }
    }
}

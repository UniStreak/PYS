﻿using System.Collections.Generic;

namespace FileIO
{

    public interface IFileAccess<TDictKey, TDictValue>
    {

        void WriteFileDB();

        void ReadFileDB();

        void OpenFileDB();

        void CloseFileDB();

        SortedDictionary<TDictKey, TDictValue> Database { get; set; }
    }
}

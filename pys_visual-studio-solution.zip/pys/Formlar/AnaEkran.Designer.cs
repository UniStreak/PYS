﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class AnaEkran
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnaEkran));
            this.AnaMenu = new System.Windows.Forms.ToolStrip();
            this.Buton_yenidb = new System.Windows.Forms.ToolStripButton();
            this.Buton_dbiceaktar = new System.Windows.Forms.ToolStripButton();
            this.Buton_dbdisaaktar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.Buton_yenipersonel = new System.Windows.Forms.ToolStripButton();
            this.Buton_duzenle = new System.Windows.Forms.ToolStripButton();
            this.Buton_sil = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.Buton_yenile = new System.Windows.Forms.ToolStripButton();
            this.Buton_ayarlar = new System.Windows.Forms.ToolStripButton();
            this.Buton_hakkinda = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.AramaKutusu = new System.Windows.Forms.ToolStripTextBox();
            this.label_arama = new System.Windows.Forms.ToolStripLabel();
            this.Buton_puantaj = new System.Windows.Forms.ToolStripButton();
            this.listView_genel = new System.Windows.Forms.ListView();
            this.IDHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tckimlikHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.adiHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.soyadiHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gtarihiHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.durumHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.departHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.meslekHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.telHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.adresHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_genelbakis = new System.Windows.Forms.TabPage();
            this.richTextBox_genelbakis = new System.Windows.Forms.RichTextBox();
            this.tabPage_ayrintilar = new System.Windows.Forms.TabPage();
            this.richTextBox_ayrintilar = new System.Windows.Forms.RichTextBox();
            this.tabPage_olaylar = new System.Windows.Forms.TabPage();
            this.Buton_olaysil = new System.Windows.Forms.Button();
            this.Buton_olayduzenle = new System.Windows.Forms.Button();
            this.listView_olaylar = new System.Windows.Forms.ListView();
            this.olay_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.olay_adi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.olay_tarihi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.olay_btarihi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.olay_aciklama = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Buton_yeniolay = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Label_DBname = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Label_sonkayit = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Count_toplamkayit = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Count_calisansayisi = new System.Windows.Forms.ToolStripStatusLabel();
            this.pictureBox_calisanfoto = new System.Windows.Forms.PictureBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.AnaMenu.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage_genelbakis.SuspendLayout();
            this.tabPage_ayrintilar.SuspendLayout();
            this.tabPage_olaylar.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_calisanfoto)).BeginInit();
            this.SuspendLayout();
            // 
            // AnaMenu
            // 
            this.AnaMenu.BackColor = System.Drawing.SystemColors.Control;
            this.AnaMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.AnaMenu.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.AnaMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Buton_yenidb,
            this.Buton_dbiceaktar,
            this.Buton_dbdisaaktar,
            this.toolStripSeparator3,
            this.Buton_yenipersonel,
            this.Buton_duzenle,
            this.Buton_sil,
            this.toolStripSeparator7,
            this.Buton_puantaj,
            this.toolStripSeparator1,
            this.Buton_yenile,
            this.Buton_ayarlar,
            this.Buton_hakkinda,
            this.toolStripLabel1,
            this.AramaKutusu,
            this.label_arama});
            this.AnaMenu.Location = new System.Drawing.Point(0, 0);
            this.AnaMenu.Name = "AnaMenu";
            this.AnaMenu.Padding = new System.Windows.Forms.Padding(2);
            this.AnaMenu.Size = new System.Drawing.Size(1350, 41);
            this.AnaMenu.TabIndex = 0;
            this.AnaMenu.Text = "AnaMenu";
            // 
            // Buton_yenidb
            // 
            this.Buton_yenidb.Image = global::pys.Properties.Resources.newdb;
            this.Buton_yenidb.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_yenidb.Name = "Buton_yenidb";
            this.Buton_yenidb.Size = new System.Drawing.Size(118, 34);
            this.Buton_yenidb.Text = "Yeni Veritabanı";
            this.Buton_yenidb.ToolTipText = "Yeni Veritabanı";
            this.Buton_yenidb.Click += new System.EventHandler(this.Buton_yenidb_Click);
            // 
            // Buton_dbiceaktar
            // 
            this.Buton_dbiceaktar.Image = global::pys.Properties.Resources.dbac;
            this.Buton_dbiceaktar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_dbiceaktar.Name = "Buton_dbiceaktar";
            this.Buton_dbiceaktar.Size = new System.Drawing.Size(87, 34);
            this.Buton_dbiceaktar.Text = "İçe Aktar";
            this.Buton_dbiceaktar.ToolTipText = "İçe Aktar";
            this.Buton_dbiceaktar.Click += new System.EventHandler(this.Buton_dbiceaktar_Click);
            // 
            // Buton_dbdisaaktar
            // 
            this.Buton_dbdisaaktar.Image = global::pys.Properties.Resources.dbfarklikaydet;
            this.Buton_dbdisaaktar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_dbdisaaktar.Name = "Buton_dbdisaaktar";
            this.Buton_dbdisaaktar.Size = new System.Drawing.Size(94, 34);
            this.Buton_dbdisaaktar.Text = "Dışa Aktar";
            this.Buton_dbdisaaktar.ToolTipText = "Dışa Aktar";
            this.Buton_dbdisaaktar.Click += new System.EventHandler(this.Buton_dbdisaaktar_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
            // 
            // Buton_yenipersonel
            // 
            this.Buton_yenipersonel.Image = global::pys.Properties.Resources.add;
            this.Buton_yenipersonel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_yenipersonel.Name = "Buton_yenipersonel";
            this.Buton_yenipersonel.Size = new System.Drawing.Size(111, 34);
            this.Buton_yenipersonel.Text = "Yeni Personel";
            this.Buton_yenipersonel.ToolTipText = "Yeni Personel";
            this.Buton_yenipersonel.Click += new System.EventHandler(this.Buton_yenipersonel_Click);
            // 
            // Buton_duzenle
            // 
            this.Buton_duzenle.Image = global::pys.Properties.Resources.edituser;
            this.Buton_duzenle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_duzenle.Name = "Buton_duzenle";
            this.Buton_duzenle.Size = new System.Drawing.Size(83, 34);
            this.Buton_duzenle.Text = "Düzenle";
            this.Buton_duzenle.ToolTipText = "Düzenle";
            this.Buton_duzenle.Click += new System.EventHandler(this.Buton_duzenle_Click);
            // 
            // Buton_sil
            // 
            this.Buton_sil.Image = global::pys.Properties.Resources.deleteuser;
            this.Buton_sil.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_sil.Name = "Buton_sil";
            this.Buton_sil.Size = new System.Drawing.Size(85, 34);
            this.Buton_sil.Text = "Kaydı Sil";
            this.Buton_sil.ToolTipText = "Kaydı Sil";
            this.Buton_sil.Click += new System.EventHandler(this.Buton_sil_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 37);
            // 
            // Buton_yenile
            // 
            this.Buton_yenile.Image = global::pys.Properties.Resources.redo;
            this.Buton_yenile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_yenile.Name = "Buton_yenile";
            this.Buton_yenile.Size = new System.Drawing.Size(72, 34);
            this.Buton_yenile.Text = "Yenile";
            this.Buton_yenile.ToolTipText = "Yenile";
            this.Buton_yenile.Click += new System.EventHandler(this.Buton_yenile_Click);
            // 
            // Buton_ayarlar
            // 
            this.Buton_ayarlar.Image = global::pys.Properties.Resources.ayarlar;
            this.Buton_ayarlar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_ayarlar.Name = "Buton_ayarlar";
            this.Buton_ayarlar.Size = new System.Drawing.Size(78, 34);
            this.Buton_ayarlar.Text = "Ayarlar";
            this.Buton_ayarlar.ToolTipText = "Ayarlar";
            this.Buton_ayarlar.Click += new System.EventHandler(this.Buton_ayarlar_Click);
            // 
            // Buton_hakkinda
            // 
            this.Buton_hakkinda.Image = global::pys.Properties.Resources.info;
            this.Buton_hakkinda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_hakkinda.Name = "Buton_hakkinda";
            this.Buton_hakkinda.Size = new System.Drawing.Size(91, 34);
            this.Buton_hakkinda.Text = "Hakkında";
            this.Buton_hakkinda.ToolTipText = "Hakkında";
            this.Buton_hakkinda.Click += new System.EventHandler(this.Buton_hakkinda_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripLabel1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(10, 34);
            this.toolStripLabel1.Text = " ";
            // 
            // AramaKutusu
            // 
            this.AramaKutusu.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.AramaKutusu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AramaKutusu.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.AramaKutusu.Margin = new System.Windows.Forms.Padding(0);
            this.AramaKutusu.MaxLength = 30;
            this.AramaKutusu.Name = "AramaKutusu";
            this.AramaKutusu.Size = new System.Drawing.Size(150, 37);
            this.AramaKutusu.ToolTipText = "Çalışanın TC kimlik numarası, adı ya da soyadı ile arama yapabilirsiniz.";
            this.AramaKutusu.TextChanged += new System.EventHandler(this.AramaKutusu_TextChanged);
            // 
            // label_arama
            // 
            this.label_arama.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.label_arama.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.label_arama.Image = global::pys.Properties.Resources.ara;
            this.label_arama.Margin = new System.Windows.Forms.Padding(0);
            this.label_arama.Name = "label_arama";
            this.label_arama.Size = new System.Drawing.Size(30, 37);
            // 
            // Buton_puantaj
            // 
            this.Buton_puantaj.Image = global::pys.Properties.Resources.puantaj;
            this.Buton_puantaj.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Buton_puantaj.Name = "Buton_puantaj";
            this.Buton_puantaj.Size = new System.Drawing.Size(81, 34);
            this.Buton_puantaj.Text = "Puantaj";
            this.Buton_puantaj.Click += new System.EventHandler(this.Buton_puantaj_Click);
            // 
            // listView_genel
            // 
            this.listView_genel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView_genel.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.IDHeader,
            this.tckimlikHeader,
            this.adiHeader,
            this.soyadiHeader,
            this.gtarihiHeader,
            this.durumHeader,
            this.departHeader,
            this.meslekHeader,
            this.telHeader,
            this.adresHeader});
            this.listView_genel.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.listView_genel.FullRowSelect = true;
            this.listView_genel.GridLines = true;
            this.listView_genel.HideSelection = false;
            this.listView_genel.Location = new System.Drawing.Point(10, 39);
            this.listView_genel.MultiSelect = false;
            this.listView_genel.Name = "listView_genel";
            this.listView_genel.Size = new System.Drawing.Size(1330, 337);
            this.listView_genel.TabIndex = 1;
            this.listView_genel.UseCompatibleStateImageBehavior = false;
            this.listView_genel.View = System.Windows.Forms.View.Details;
            this.listView_genel.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView_genel_ColumnClick);
            this.listView_genel.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.listView_genel_SelectedIndexChanged);
            // 
            // IDHeader
            // 
            this.IDHeader.Text = "ID";
            this.IDHeader.Width = 70;
            // 
            // tckimlikHeader
            // 
            this.tckimlikHeader.Text = "TC Kimlik No";
            this.tckimlikHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tckimlikHeader.Width = 121;
            // 
            // adiHeader
            // 
            this.adiHeader.Text = "Adı";
            this.adiHeader.Width = 120;
            // 
            // soyadiHeader
            // 
            this.soyadiHeader.Text = "Soyadı";
            this.soyadiHeader.Width = 130;
            // 
            // gtarihiHeader
            // 
            this.gtarihiHeader.Text = "Giriş Tarihi";
            this.gtarihiHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gtarihiHeader.Width = 202;
            // 
            // durumHeader
            // 
            this.durumHeader.Text = "Durum";
            this.durumHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // departHeader
            // 
            this.departHeader.Text = "Departman";
            this.departHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.departHeader.Width = 100;
            // 
            // meslekHeader
            // 
            this.meslekHeader.Text = "Meslek";
            this.meslekHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.meslekHeader.Width = 200;
            // 
            // telHeader
            // 
            this.telHeader.Text = "Telefon";
            this.telHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.telHeader.Width = 115;
            // 
            // adresHeader
            // 
            this.adresHeader.Text = "Adres";
            this.adresHeader.Width = 225;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage_genelbakis);
            this.tabControl1.Controls.Add(this.tabPage_ayrintilar);
            this.tabControl1.Controls.Add(this.tabPage_olaylar);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabControl1.Location = new System.Drawing.Point(231, 382);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1109, 252);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage_genelbakis
            // 
            this.tabPage_genelbakis.Controls.Add(this.richTextBox_genelbakis);
            this.tabPage_genelbakis.Location = new System.Drawing.Point(4, 26);
            this.tabPage_genelbakis.Name = "tabPage_genelbakis";
            this.tabPage_genelbakis.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_genelbakis.Size = new System.Drawing.Size(1101, 222);
            this.tabPage_genelbakis.TabIndex = 0;
            this.tabPage_genelbakis.Text = "Genel Bakış";
            this.tabPage_genelbakis.UseVisualStyleBackColor = true;
            // 
            // richTextBox_genelbakis
            // 
            this.richTextBox_genelbakis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_genelbakis.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox_genelbakis.Location = new System.Drawing.Point(3, 3);
            this.richTextBox_genelbakis.Name = "richTextBox_genelbakis";
            this.richTextBox_genelbakis.ReadOnly = true;
            this.richTextBox_genelbakis.Size = new System.Drawing.Size(1095, 216);
            this.richTextBox_genelbakis.TabIndex = 1;
            this.richTextBox_genelbakis.Text = "";
            // 
            // tabPage_ayrintilar
            // 
            this.tabPage_ayrintilar.Controls.Add(this.richTextBox_ayrintilar);
            this.tabPage_ayrintilar.Location = new System.Drawing.Point(4, 26);
            this.tabPage_ayrintilar.Name = "tabPage_ayrintilar";
            this.tabPage_ayrintilar.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_ayrintilar.Size = new System.Drawing.Size(1101, 222);
            this.tabPage_ayrintilar.TabIndex = 1;
            this.tabPage_ayrintilar.Text = "Ayrıntılar";
            this.tabPage_ayrintilar.UseVisualStyleBackColor = true;
            // 
            // richTextBox_ayrintilar
            // 
            this.richTextBox_ayrintilar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_ayrintilar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox_ayrintilar.Location = new System.Drawing.Point(3, 3);
            this.richTextBox_ayrintilar.Name = "richTextBox_ayrintilar";
            this.richTextBox_ayrintilar.ReadOnly = true;
            this.richTextBox_ayrintilar.Size = new System.Drawing.Size(1095, 216);
            this.richTextBox_ayrintilar.TabIndex = 3;
            this.richTextBox_ayrintilar.Text = "";
            // 
            // tabPage_olaylar
            // 
            this.tabPage_olaylar.Controls.Add(this.Buton_olaysil);
            this.tabPage_olaylar.Controls.Add(this.Buton_olayduzenle);
            this.tabPage_olaylar.Controls.Add(this.listView_olaylar);
            this.tabPage_olaylar.Controls.Add(this.Buton_yeniolay);
            this.tabPage_olaylar.Location = new System.Drawing.Point(4, 26);
            this.tabPage_olaylar.Name = "tabPage_olaylar";
            this.tabPage_olaylar.Size = new System.Drawing.Size(1101, 222);
            this.tabPage_olaylar.TabIndex = 2;
            this.tabPage_olaylar.Text = "Olaylar";
            this.tabPage_olaylar.UseVisualStyleBackColor = true;
            // 
            // Buton_olaysil
            // 
            this.Buton_olaysil.Location = new System.Drawing.Point(192, 190);
            this.Buton_olaysil.Name = "Buton_olaysil";
            this.Buton_olaysil.Size = new System.Drawing.Size(90, 30);
            this.Buton_olaysil.TabIndex = 3;
            this.Buton_olaysil.Text = "Sil";
            this.Buton_olaysil.UseVisualStyleBackColor = true;
            this.Buton_olaysil.Click += new System.EventHandler(this.Buton_olaysil_Click);
            // 
            // Buton_olayduzenle
            // 
            this.Buton_olayduzenle.Location = new System.Drawing.Point(96, 190);
            this.Buton_olayduzenle.Name = "Buton_olayduzenle";
            this.Buton_olayduzenle.Size = new System.Drawing.Size(90, 30);
            this.Buton_olayduzenle.TabIndex = 2;
            this.Buton_olayduzenle.Text = "Düzenle";
            this.Buton_olayduzenle.UseVisualStyleBackColor = true;
            this.Buton_olayduzenle.Click += new System.EventHandler(this.Buton_olayduzenle_Click);
            // 
            // listView_olaylar
            // 
            this.listView_olaylar.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olay_id,
            this.olay_adi,
            this.olay_tarihi,
            this.olay_btarihi,
            this.olay_aciklama});
            this.listView_olaylar.Dock = System.Windows.Forms.DockStyle.Top;
            this.listView_olaylar.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.listView_olaylar.FullRowSelect = true;
            this.listView_olaylar.HideSelection = false;
            this.listView_olaylar.Location = new System.Drawing.Point(0, 0);
            this.listView_olaylar.MultiSelect = false;
            this.listView_olaylar.Name = "listView_olaylar";
            this.listView_olaylar.Size = new System.Drawing.Size(1101, 187);
            this.listView_olaylar.TabIndex = 0;
            this.listView_olaylar.UseCompatibleStateImageBehavior = false;
            this.listView_olaylar.View = System.Windows.Forms.View.Details;
            // 
            // olay_id
            // 
            this.olay_id.Text = "ID";
            // 
            // olay_adi
            // 
            this.olay_adi.Text = "Olay Adı";
            this.olay_adi.Width = 200;
            // 
            // olay_tarihi
            // 
            this.olay_tarihi.Text = "Başlangıç Tarihi";
            this.olay_tarihi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olay_tarihi.Width = 202;
            // 
            // olay_btarihi
            // 
            this.olay_btarihi.Text = "Bitiş Tarihi";
            this.olay_btarihi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.olay_btarihi.Width = 202;
            // 
            // olay_aciklama
            // 
            this.olay_aciklama.Text = "Açıklama";
            this.olay_aciklama.Width = 850;
            // 
            // Buton_yeniolay
            // 
            this.Buton_yeniolay.Location = new System.Drawing.Point(0, 190);
            this.Buton_yeniolay.Name = "Buton_yeniolay";
            this.Buton_yeniolay.Size = new System.Drawing.Size(90, 30);
            this.Buton_yeniolay.TabIndex = 1;
            this.Buton_yeniolay.Text = "Yeni";
            this.Buton_yeniolay.UseVisualStyleBackColor = true;
            this.Buton_yeniolay.Click += new System.EventHandler(this.Buton_yeniolay_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.Label_DBname,
            this.toolStripStatusLabel2,
            this.Label_sonkayit,
            this.toolStripStatusLabel4,
            this.Count_toplamkayit,
            this.toolStripStatusLabel5,
            this.Count_calisansayisi});
            this.statusStrip1.Location = new System.Drawing.Point(0, 637);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1350, 24);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(73, 19);
            this.toolStripStatusLabel1.Text = "Veritabanı:";
            // 
            // Label_DBname
            // 
            this.Label_DBname.Name = "Label_DBname";
            this.Label_DBname.Size = new System.Drawing.Size(59, 19);
            this.Label_DBname.Text = "(tanımsız)";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.toolStripStatusLabel2.Margin = new System.Windows.Forms.Padding(3, 3, 0, 2);
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(118, 19);
            this.toolStripStatusLabel2.Text = "Son Kayıt Zamanı:";
            // 
            // Label_sonkayit
            // 
            this.Label_sonkayit.Name = "Label_sonkayit";
            this.Label_sonkayit.Size = new System.Drawing.Size(77, 19);
            this.Label_sonkayit.Text = "Hiçbir zaman";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.toolStripStatusLabel4.Margin = new System.Windows.Forms.Padding(3, 3, 0, 2);
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(90, 19);
            this.toolStripStatusLabel4.Text = "Toplam Kayıt:";
            // 
            // Count_toplamkayit
            // 
            this.Count_toplamkayit.Name = "Count_toplamkayit";
            this.Count_toplamkayit.Size = new System.Drawing.Size(13, 19);
            this.Count_toplamkayit.Text = "0";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.toolStripStatusLabel5.Margin = new System.Windows.Forms.Padding(3, 3, 0, 2);
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(92, 19);
            this.toolStripStatusLabel5.Text = "Çalışan Sayısı:";
            // 
            // Count_calisansayisi
            // 
            this.Count_calisansayisi.Name = "Count_calisansayisi";
            this.Count_calisansayisi.Size = new System.Drawing.Size(13, 19);
            this.Count_calisansayisi.Text = "0";
            // 
            // pictureBox_calisanfoto
            // 
            this.pictureBox_calisanfoto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox_calisanfoto.Image = global::pys.Properties.Resources.Unknown_Person;
            this.pictureBox_calisanfoto.Location = new System.Drawing.Point(12, 414);
            this.pictureBox_calisanfoto.Name = "pictureBox_calisanfoto";
            this.pictureBox_calisanfoto.Size = new System.Drawing.Size(213, 216);
            this.pictureBox_calisanfoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_calisanfoto.TabIndex = 3;
            this.pictureBox_calisanfoto.TabStop = false;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // AnaEkran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1350, 661);
            this.Controls.Add(this.pictureBox_calisanfoto);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.listView_genel);
            this.Controls.Add(this.AnaMenu);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1366, 700);
            this.Name = "AnaEkran";
            this.Text = "Personel Yönetim Sistemi";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AnaEkran_FormClosing);
            this.AnaMenu.ResumeLayout(false);
            this.AnaMenu.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage_genelbakis.ResumeLayout(false);
            this.tabPage_ayrintilar.ResumeLayout(false);
            this.tabPage_olaylar.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_calisanfoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip AnaMenu;
        private System.Windows.Forms.ToolStripButton Buton_yenipersonel;
        private System.Windows.Forms.ToolStripButton Buton_duzenle;
        private System.Windows.Forms.ToolStripButton Buton_yenile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton Buton_yenidb;
        private System.Windows.Forms.ToolStripButton Buton_sil;
        private System.Windows.Forms.ToolStripTextBox AramaKutusu;
        private System.Windows.Forms.ToolStripLabel label_arama;
        private System.Windows.Forms.ToolStripButton Buton_ayarlar;
        private System.Windows.Forms.ToolStripButton Buton_hakkinda;
        private System.Windows.Forms.ListView listView_genel;
        private System.Windows.Forms.ColumnHeader IDHeader;
        private System.Windows.Forms.ColumnHeader tckimlikHeader;
        private System.Windows.Forms.ColumnHeader adiHeader;
        private System.Windows.Forms.ColumnHeader soyadiHeader;
        private System.Windows.Forms.ColumnHeader gtarihiHeader;
        private System.Windows.Forms.ColumnHeader durumHeader;
        private System.Windows.Forms.ColumnHeader departHeader;
        private System.Windows.Forms.ColumnHeader meslekHeader;
        private System.Windows.Forms.ColumnHeader telHeader;
        private System.Windows.Forms.ColumnHeader adresHeader;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_genelbakis;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel Label_DBname;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel Label_sonkayit;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel Count_toplamkayit;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel Count_calisansayisi;
        private System.Windows.Forms.TabPage tabPage_ayrintilar;
        private System.Windows.Forms.TabPage tabPage_olaylar;
        private System.Windows.Forms.ToolStripButton Buton_dbiceaktar;
        private System.Windows.Forms.ToolStripButton Buton_dbdisaaktar;
        private System.Windows.Forms.RichTextBox richTextBox_genelbakis;
        private System.Windows.Forms.RichTextBox richTextBox_ayrintilar;
        private System.Windows.Forms.Button Buton_olaysil;
        private System.Windows.Forms.Button Buton_olayduzenle;
        private System.Windows.Forms.ListView listView_olaylar;
        private System.Windows.Forms.ColumnHeader olay_id;
        private System.Windows.Forms.ColumnHeader olay_adi;
        private System.Windows.Forms.ColumnHeader olay_tarihi;
        private System.Windows.Forms.ColumnHeader olay_aciklama;
        private System.Windows.Forms.Button Buton_yeniolay;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ColumnHeader olay_btarihi;
        private System.Windows.Forms.PictureBox pictureBox_calisanfoto;
        private System.Windows.Forms.ToolStripButton Buton_puantaj;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}


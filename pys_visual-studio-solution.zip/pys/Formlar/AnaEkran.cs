﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using pys.Diger;
using pys.Personel;
using FileIO;
using System.Collections;

namespace pys
{
    public partial class AnaEkran : Form
    {
        public DBfunctions<uint, Calisan> datafile;
        private string FileName;
        
        public AnaEkran()
        {
            InitializeComponent();
            datafile = new DBfunctions<uint, Calisan>();
            FileName = string.Empty;
            listView_genel.Sort();
            listView_genel.ListViewItemSorter = new SayiSirala(0, listView_genel.Sorting);
        }

        private void Buton_hakkinda_Click(object sender, EventArgs e)
        {
            Hakkinda hakkindaDialog = new Hakkinda();
            hakkindaDialog.ShowDialog();
        }

        DialogResult ndbdr = DialogResult.No;
        private void Buton_yenidb_Click(object sender, EventArgs e)
        {
            if (datafile != null)
            {
                ndbdr = MessageBox.Show(Strings.Confirmation.CONFIRM_SAVEDATABASE, Strings.Confirmation.CONFIRM_TITLE,
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (ndbdr == DialogResult.Yes)
                {
                    SaveData_();
                    datafile = new DBfunctions<uint, Calisan>();
                    FileName = string.Empty;
                    listView_genel.Items.Clear();
                    listView_olaylar.Items.Clear();
                    Label_DBname.Text = "(tanımsız)";
                    Count_toplamkayit.Text = datafile.CountVisible().ToString();
                    Count_calisansayisi.Text = datafile.CountCalisan().ToString();
                }
                else if (ndbdr == DialogResult.No)
                {
                    datafile = new DBfunctions<uint, Calisan>();
                    FileName = string.Empty;
                    listView_genel.Items.Clear();
                    listView_olaylar.Items.Clear();
                    Label_DBname.Text = "(tanımsız)";
                    Count_toplamkayit.Text = datafile.CountVisible().ToString();
                    Count_calisansayisi.Text = datafile.CountCalisan().ToString();
                }

            }
        }

        private void Buton_dbiceaktar_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog open = new OpenFileDialog())
            {
                open.Filter = Strings.FileInfo.FILE_FILTER;
                if (open.ShowDialog() == DialogResult.OK)
                {
                    ImportData(open.FileName);
                }
            }
        }

        private void Buton_dbdisaaktar_Click(object sender, EventArgs e)
        {
            SaveData(false);
        }

        private void Buton_yenipersonel_Click(object sender, EventArgs e)
        {
            int id = datafile.Size + 1;            
            using (Kayit form = new Kayit(id))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        
                        datafile.Add((uint)form._Calisan.CalisanID, form._Calisan);                        
                        AddItem(datafile.Retrieve((uint)form._Calisan.CalisanID));
                        SaveData_();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, Strings.Errors.ERROR_TITLE);                        
                    }
                }
            }
            
        }

        private void Buton_duzenle_Click(object sender, EventArgs e)
        {
            if (listView_genel.SelectedItems.Count == 0)
            {
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED,
                    Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            uint id = uint.Parse(listView_genel.SelectedItems[0].Text);
            using (Kayit form = new Kayit(datafile.Retrieve(id)))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    datafile.Remove(id);
                    datafile.Add((uint)form._Calisan.CalisanID, form._Calisan);
                    listView_genel.SelectedItems[0].Remove();
                    AddItem(form._Calisan);
                    SaveData_();
                }
            }            
        }

        private void Buton_sil_Click(object sender, EventArgs e)
        {
            if (listView_genel.SelectedIndices.Count == 0)
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED,
                    Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            else
            {
                if (MessageBox.Show(Strings.Confirmation.CONFIRM_ACTION,
                Strings.Confirmation.CONFIRM_TITLE,
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    uint id = uint.Parse(listView_genel.SelectedItems[0].Text);
                    datafile.Retrieve(id).IsVisible = false;
                    listView_genel.Items.RemoveAt(listView_genel.SelectedIndices[0]);
                }
            }
            SaveData_();
        }

        private void Buton_yenile_Click(object sender, EventArgs e)
        {
            DisplayDatabase();
            listView_genel.Sort();
            listView_genel.ListViewItemSorter = new SayiSirala(0, listView_genel.Sorting);
        }

        private void Buton_ayarlar_Click(object sender, EventArgs e)
        {
            Ayarlar ayarlar = new Ayarlar();
            ayarlar.ShowDialog();
        }

        private void Buton_yeniolay_Click(object sender, EventArgs e)
        {
            if (listView_genel.SelectedItems.Count == 0)
            {
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED,
                    Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            uint id = uint.Parse(listView_genel.SelectedItems[0].Text);
            using (OlayEkle form = new OlayEkle())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    Olay olay = form._Olay;
                    var emp = datafile.Retrieve(id);
                    emp._PersonelOlaylari.Olaylar.Add(olay.OlayID, olay);
                    AddItem(olay);
                    SaveData_();
                }
            }
            
        }

        private void Buton_olayduzenle_Click(object sender, EventArgs e)
        {
            if (listView_olaylar.SelectedItems.Count == 0)
            {
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED, Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            OlayDuzenle(uint.Parse(listView_genel.SelectedItems[0].Text),
                listView_olaylar.SelectedItems[0].Text);
        }

        private void Buton_olaysil_Click(object sender, EventArgs e)
        {
            if (listView_olaylar.SelectedItems.Count == 0)
            {
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED, Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (MessageBox.Show(Strings.Confirmation.CONFIRM_ACTION,
                Strings.Confirmation.CONFIRM_TITLE,
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                uint id = uint.Parse(listView_genel.SelectedItems[0].Text);
                datafile.Retrieve(id)._PersonelOlaylari.Olaylar.Remove(listView_olaylar.SelectedItems[0].Text);
                listView_olaylar.Items.RemoveAt(listView_olaylar.SelectedIndices[0]);
            }
            SaveData_();
        }

        private void listView_genel_SelectedIndexChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            ListViewItem lvi = e.Item;
            if (lvi != null)
            {
                var emp = datafile.Retrieve(uint.Parse(lvi.Text));
                System.Text.StringBuilder details = new System.Text.StringBuilder();
                details.AppendLine($"|{emp.CalisanID}|");
                details.AppendLine($"Adı Soyadı\t: {emp._CalisanKayit.Adi} {emp._CalisanKayit.Soyadi}");
                details.AppendLine($"TC Kimlik No\t: {emp._CalisanKayit.TC_Kimlik}");
                details.AppendLine($"Giriş tarihi\t: {emp._CalisanKayit.GirisT}");
                DateTime gTarih = Convert.ToDateTime(emp._CalisanKayit.GirisT);
                DateTime bTarih;
                if (emp._CalisanKayit.CikisTCheck)
                {
                    bTarih = Convert.ToDateTime(emp._CalisanKayit.CikisT);
                }
                else
                {
                    bTarih = Convert.ToDateTime(DateTime.Now.ToLongDateString());
                }
                TimeSpan fark = bTarih - gTarih;
                string calismasuresi = fark.TotalDays.ToString();
                int calismagunu = Convert.ToInt32(calismasuresi);
                details.AppendLine($"Hizmet süresi\t: Yaklaşık {calismagunu / 365} yıl {(calismagunu % 365) / 30} ay {calismagunu % 365 % 30} gün");
                details.AppendLine($"Pozisyon\t: {emp._CalisanKayit.Departman} | {emp._CalisanKayit.Pozisyon}");
                details.AppendLine($"Telefon\t: {emp._CalisanKayit.Telefon}");
                string medenihali;
                string cocuksayisi;
                string kang;
                if (emp._CalisanKayit.MedeniHali == "")
                    medenihali = "bilinmiyor";
                else
                    medenihali = emp._CalisanKayit.MedeniHali;
                if (emp._CalisanKayit.CocukSayisi == "")
                    cocuksayisi = "bilinmiyor";
                else
                    cocuksayisi = emp._CalisanKayit.CocukSayisi;
                if (emp._CalisanKayit.KanGrubu == "")
                    kang = "bilinmiyor";
                else
                    kang = emp._CalisanKayit.KanGrubu;
                details.AppendLine($"Kan Grubu\t: {kang}\tMedeni Hali : {medenihali}\tÇocuk Sayısı : {cocuksayisi}");
                details.AppendLine($"Adres\t:  {emp._CalisanKayit.Adres}");
                if (emp._CalisanKayit.CikisTCheck)
                {
                    details.AppendLine($"\nNOT\t:  {emp._CalisanKayit.CikisT} tarihinde ayrıldı.");
                }

                System.Text.StringBuilder ayrintilar = new System.Text.StringBuilder();
                ayrintilar.AppendLine($"Ek bilgi:\n");
                if (emp._CalisanKayit.EkBilgi == "")
                    ayrintilar.AppendLine($"Ek bilgi sağlanmadı.");
                else
                    ayrintilar.AppendLine($"{emp._CalisanKayit.EkBilgi}");

                richTextBox_genelbakis.Text = details.ToString();
                richTextBox_ayrintilar.Text = ayrintilar.ToString();

                pictureBox_calisanfoto.ImageLocation = emp._CalisanKayit.FotoYolu;

                if (emp._CalisanKayit.FotoYolu == "")
                {
                    pictureBox_calisanfoto.Image = Properties.Resources.Unknown_Person;
                }

                listView_olaylar.Items.Clear();
                listView_olaylar.BeginUpdate();
                foreach (var olay in emp._PersonelOlaylari.Olaylar.Values)
                {
                    AddItem(olay);
                }
                listView_olaylar.EndUpdate();
            }
            else
            {
                pictureBox_calisanfoto.Image = Properties.Resources.Unknown_Person;
                richTextBox_genelbakis.Clear();
                richTextBox_ayrintilar.Clear();
                listView_olaylar.Items.Clear();

            }
        }

        private void AddItem(Calisan emp)
        {
            if (emp == null) throw new ArgumentNullException(Strings.Errors.INVALID_OBJECT);

            ListViewItem lvi = new ListViewItem($"{emp.CalisanID}");
            lvi.SubItems.Add($"{emp._CalisanKayit.TC_Kimlik}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Adi}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Soyadi}");
            lvi.SubItems.Add($"{emp._CalisanKayit.GirisT}");
            if (emp._CalisanKayit.CikisTCheck == true)
            {
                lvi.SubItems.Add($"x");
            }
            else
            {
                lvi.SubItems.Add($"✓");
            }
            lvi.SubItems.Add($"{emp._CalisanKayit.Departman}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Pozisyon}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Telefon}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Adres}");
            
            listView_genel.Items.Add(lvi);
            Count_toplamkayit.Text = datafile.CountVisible().ToString();
            Count_calisansayisi.Text = datafile.CountCalisan().ToString();
        }

        private void AddItem(Olay olay)
        {
            
            ListViewItem lvi = new ListViewItem($"{olay.OlayID}");
            lvi.SubItems.Add($"{olay.OlayAdi}");
            if (olay.BaslangicTarihiCheck&&olay.BaslangicSaatiCheck)
                lvi.SubItems.Add($"{olay.BaslangicTarihi} {olay.BaslangicSaati}");
            else if (!(olay.BaslangicTarihiCheck) && olay.BaslangicSaatiCheck)
                lvi.SubItems.Add($"{olay.BaslangicSaati}");
            else if (olay.BaslangicTarihiCheck && !(olay.BaslangicSaatiCheck))
                lvi.SubItems.Add($"{olay.BaslangicTarihi}");
            else
                lvi.SubItems.Add($"-");
            if (olay.BitisTarihiCheck && olay.BitisSaatiCheck)
                lvi.SubItems.Add($"{olay.BitisTarihi} {olay.BitisSaati}");
            else if (!(olay.BitisTarihiCheck) && olay.BitisSaatiCheck)
                lvi.SubItems.Add($"{olay.BitisSaati}");
            else if (olay.BitisTarihiCheck && !(olay.BitisSaatiCheck))
                lvi.SubItems.Add($"{olay.BitisTarihi}");
            else
                lvi.SubItems.Add($"-");

            lvi.SubItems.Add($"{olay.OlayAciklamasi}");
            
            listView_olaylar.Items.Add(lvi);
        }

        internal void ImportData(string fileName)
        {
            FileName = fileName;
            
            using (XmlFileIO<uint, Calisan> file =
                new XmlFileIO<uint, Calisan>(fileName, datafile.Database,
                Strings.FileInfo.DEFAULT_ROOT, Strings.FileInfo.DEFAULT_NAMESPACE))
            {
                try
                {
                    file.OpenFileDB();
                    file.ReadFileDB();
                    file.CloseFileDB();
                }
                catch (FileStatusException ex)
                {
                    MessageBox.Show(ex.Message, Strings.Errors.ERROR_TITLE,
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                datafile.Database = file.Database;

                Label_DBname.Text = file.FileInfo.FullName;
                Label_sonkayit.Text = System.IO.File.GetLastWriteTime(file.FileInfo.FullName).ToShortTimeString();
            }
            Count_toplamkayit.Text = datafile.CountVisible().ToString();
            Count_calisansayisi.Text = datafile.CountCalisan().ToString();
            
            DisplayDatabase();
        }

        private void SaveData(bool overwrite)
        {
            if (overwrite)
            {
                using (XmlFileIO<uint, Calisan> file =
                    new XmlFileIO<uint, Calisan>(FileName, System.IO.FileMode.Truncate, datafile.Database,
                    Strings.FileInfo.DEFAULT_ROOT, Strings.FileInfo.DEFAULT_NAMESPACE))
                {
                    try
                    {
                        file.OpenFileDB();
                        file.WriteFileDB();
                        file.CloseFileDB();
                    }
                    catch (FileStatusException ex)
                    {
                        MessageBox.Show(ex.Message, Strings.Errors.ERROR_TITLE,
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    Label_DBname.Text = FileName;
                    Label_sonkayit.Text = System.IO.File.GetLastWriteTime(FileName).ToShortTimeString();
                }
            }
            else
            {
                using (SaveFileDialog dialog = new SaveFileDialog())
                {
                    dialog.Filter = Strings.FileInfo.FILE_FILTER;
                    if (dialog.ShowDialog() == DialogResult.OK)
                    {
                        FileName = dialog.FileName;

                        if (!System.IO.File.Exists(FileName))
                            System.IO.File.Create(FileName).Close();
                        using (XmlFileIO<uint, Calisan> file =
                            new XmlFileIO<uint, Calisan>(FileName, datafile.Database,
                            Strings.FileInfo.DEFAULT_ROOT, Strings.FileInfo.DEFAULT_NAMESPACE))
                        {
                            try
                            {
                                file.OpenFileDB();
                                file.WriteFileDB();
                                file.CloseFileDB();
                            }
                            catch (FileStatusException ex)
                            {
                                MessageBox.Show(ex.Message, Strings.Errors.ERROR_TITLE,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                        Label_DBname.Text = FileName;
                        Label_sonkayit.Text = System.IO.File.GetLastWriteTime(FileName).ToShortTimeString();
                    }
                }
            }
        }

        public void SaveData_()
        {
            if (string.IsNullOrEmpty(FileName))
            {
                SaveData(false);
            }
            else
            {
                SaveData(true);
            }
        }

        private void DisplayDatabase()
        {

            if (listView_genel.Items.Count > 0)
                listView_genel.Items.Clear();

            listView_genel.BeginUpdate();
            foreach (var emp in datafile.Database.Values)
            {
                if (emp.IsVisible)
                    AddItem(emp);
            }
            listView_genel.EndUpdate();
        }

        private void OlayDuzenle(uint empID, string olayID)
        {
            var emp = datafile.Retrieve(empID);
            Olay olay = emp._PersonelOlaylari.Olaylar[olayID];
            using (OlayEkle form = new OlayEkle(olay))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    emp._PersonelOlaylari.Olaylar[olayID] = form._Olay;
                    listView_olaylar.SelectedItems[0].Remove();
                    AddItem(form._Olay);
                    SaveData_();
                }
            }
        }
               
        private bool Kapatsorgu;
        DialogResult dr = DialogResult.No;
        private void AnaEkran_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!Kapatsorgu) 
            {
                dr = MessageBox.Show(Strings.Confirmation.CONFIRM_ACTION, Strings.Confirmation.CONFIRM_TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                Kapatsorgu = dr == DialogResult.Yes;
            }
            if (dr == DialogResult.Yes)
            {
                if (Kapatsorgu)
                {                    
                    Application.Exit();
                }
                Kapatsorgu = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void AramaKutusu_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(AramaKutusu.Text))
                DisplayDatabase();
            IEnumerable<Calisan> query;
            query = datafile.Database.Values.Where(x => x._CalisanKayit.TC_Kimlik == AramaKutusu.Text).ToList();
            if (query.Count() > 0)
            {
                listView_genel.Items.Clear();
                listView_genel.BeginUpdate();
                foreach (var emp in query)
                {
                    AddItem(emp);
                }
                listView_genel.EndUpdate();
            }
            else
            {
                query = datafile.Database.Values.Where(x => x._CalisanKayit.Adi.ToLower() == AramaKutusu.Text).ToList();
                if (query.Count() > 0)
                {
                    listView_genel.Items.Clear();
                    listView_genel.BeginUpdate();
                    foreach (var emp in query)
                    {
                        AddItem(emp);
                    }
                    listView_genel.EndUpdate();
                }
                else
                {
                    query = datafile.Database.Values.Where(x => x._CalisanKayit.Soyadi.ToLower() == AramaKutusu.Text).ToList();
                    if (query.Count() > 0)
                    {
                        listView_genel.Items.Clear();
                        listView_genel.BeginUpdate();
                        foreach (var emp in query)
                        {
                            AddItem(emp);
                        }
                        listView_genel.EndUpdate();
                    }
                    
                }
            }
        }

        public class SayiSirala : IComparer
        {

            private int col;
            private SortOrder order;
            public SayiSirala()
            {
                col = 0;
                order = SortOrder.Ascending;
            }
            public SayiSirala(int column, SortOrder order)
            {
                col = column;
                this.order = order;
            }
            public int Compare(object x, object y)
            {
                int returnVal = -1;
                int intx = 0, inty = 0;
                if (!Int32.TryParse(((ListViewItem)x).SubItems[col].Text, out intx)) intx = 0;
                if (!Int32.TryParse(((ListViewItem)y).SubItems[col].Text, out inty)) inty = 0;
                returnVal = intx.CompareTo(inty);

                if (order == SortOrder.Descending) returnVal *= -1;
                return returnVal;
            }
        }

        public class HarfSirala : IComparer
        {
            public int Column { get; set; }

            public SortOrder Order { get; set; }
            public HarfSirala(int colIndex)
            {
                Column = colIndex;
                Order = SortOrder.None;

            }
            public int Compare(object a, object b)
            {
                int result;

                ListViewItem itemA = a as ListViewItem;
                ListViewItem itemB = b as ListViewItem;
                if (itemA == null && itemB == null)
                result = 0;
            else if (itemA == null)
                    result = -1;
                else if (itemB == null)
                    result = 1;

                if (itemA == itemB)
                    result = 0;

                DateTime x1, y1;

                if (!DateTime.TryParse(itemA.SubItems[Column].Text, out x1))
                    x1 = DateTime.MinValue;
                if (!DateTime.TryParse(itemB.SubItems[Column].Text, out y1))
                    y1 = DateTime.MinValue;
                result = DateTime.Compare(x1, y1);

                if (x1 != DateTime.MinValue && y1 != DateTime.MinValue)
                goto done;

                decimal x2, y2;
                if (!Decimal.TryParse(itemA.SubItems[Column].Text, out x2))
                    x2 = Decimal.MinValue;
                if (!Decimal.TryParse(itemB.SubItems[Column].Text, out y2))
                    y2 = Decimal.MinValue;
                result = Decimal.Compare(x2, y2);

                if (x2 != Decimal.MinValue && y2 != Decimal.MinValue)
                goto done;
                result = String.Compare(itemA.SubItems[Column].Text, itemB.SubItems[Column].Text);
            done:
                if (Order == SortOrder.Descending)
                    result *= -1;
                return result;

            }
        }

        private void listView_genel_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            HarfSirala sira = listView_genel.ListViewItemSorter as HarfSirala;

            if (sira == null)
            {
                sira = new HarfSirala(e.Column);
                sira.Order = SortOrder.Ascending;
                listView_genel.ListViewItemSorter = sira;
            }

            if (e.Column == sira.Column)
            {
                
                if (sira.Order == SortOrder.Ascending)
                    sira.Order = SortOrder.Descending;
                else
                    sira.Order = SortOrder.Ascending;
            }
            else
            {

                sira.Column = e.Column;
                sira.Order = SortOrder.Ascending;
            }
            listView_genel.Sort();
        }

        private void Buton_puantaj_Click(object sender, EventArgs e)
        {
            using (PuantajEkrani form = new PuantajEkrani(datafile))
            {
                form.ShowDialog();
                datafile = form.pdatafile;
                SaveData_();                
            }

        }
    }
}

﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class Ayarlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ayarlar));
            this.groupBox_DBayarlari = new System.Windows.Forms.GroupBox();
            this.Buton_GozatDByolu = new System.Windows.Forms.Button();
            this.textBox_DByolu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Buton_ayarkaydet = new System.Windows.Forms.Button();
            this.Buton_ayariptal = new System.Windows.Forms.Button();
            this.groupBox_DBayarlari.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_DBayarlari
            // 
            this.groupBox_DBayarlari.Controls.Add(this.Buton_GozatDByolu);
            this.groupBox_DBayarlari.Controls.Add(this.textBox_DByolu);
            this.groupBox_DBayarlari.Controls.Add(this.label1);
            this.groupBox_DBayarlari.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox_DBayarlari.Location = new System.Drawing.Point(12, 12);
            this.groupBox_DBayarlari.Name = "groupBox_DBayarlari";
            this.groupBox_DBayarlari.Size = new System.Drawing.Size(631, 99);
            this.groupBox_DBayarlari.TabIndex = 0;
            this.groupBox_DBayarlari.TabStop = false;
            this.groupBox_DBayarlari.Text = "Veritabanı Ayarları";
            // 
            // Buton_GozatDByolu
            // 
            this.Buton_GozatDByolu.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_GozatDByolu.Location = new System.Drawing.Point(525, 43);
            this.Buton_GozatDByolu.Name = "Buton_GozatDByolu";
            this.Buton_GozatDByolu.Size = new System.Drawing.Size(87, 25);
            this.Buton_GozatDByolu.TabIndex = 2;
            this.Buton_GozatDByolu.Text = "Gözat";
            this.Buton_GozatDByolu.UseVisualStyleBackColor = true;
            this.Buton_GozatDByolu.Click += new System.EventHandler(this.Buton_GozatDByolu_Click);
            // 
            // textBox_DByolu
            // 
            this.textBox_DByolu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox_DByolu.Location = new System.Drawing.Point(190, 43);
            this.textBox_DByolu.Name = "textBox_DByolu";
            this.textBox_DByolu.Size = new System.Drawing.Size(329, 25);
            this.textBox_DByolu.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(28, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Varsayılan Veritabanı Yolu";
            // 
            // Buton_ayarkaydet
            // 
            this.Buton_ayarkaydet.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_ayarkaydet.Location = new System.Drawing.Point(437, 117);
            this.Buton_ayarkaydet.Name = "Buton_ayarkaydet";
            this.Buton_ayarkaydet.Size = new System.Drawing.Size(100, 30);
            this.Buton_ayarkaydet.TabIndex = 1;
            this.Buton_ayarkaydet.Text = "Kaydet";
            this.Buton_ayarkaydet.UseVisualStyleBackColor = true;
            this.Buton_ayarkaydet.Click += new System.EventHandler(this.Buton_ayarkaydet_Click);
            // 
            // Buton_ayariptal
            // 
            this.Buton_ayariptal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_ayariptal.Location = new System.Drawing.Point(543, 117);
            this.Buton_ayariptal.Name = "Buton_ayariptal";
            this.Buton_ayariptal.Size = new System.Drawing.Size(100, 30);
            this.Buton_ayariptal.TabIndex = 2;
            this.Buton_ayariptal.Text = "İptal";
            this.Buton_ayariptal.UseVisualStyleBackColor = true;
            this.Buton_ayariptal.Click += new System.EventHandler(this.Buton_ayariptal_Click);
            // 
            // Ayarlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 156);
            this.ControlBox = false;
            this.Controls.Add(this.Buton_ayariptal);
            this.Controls.Add(this.Buton_ayarkaydet);
            this.Controls.Add(this.groupBox_DBayarlari);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Ayarlar";
            this.Text = "Personel Yönetim Sistemi Ayarları";
            this.groupBox_DBayarlari.ResumeLayout(false);
            this.groupBox_DBayarlari.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_DBayarlari;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Buton_GozatDByolu;
        private System.Windows.Forms.TextBox textBox_DByolu;
        private System.Windows.Forms.Button Buton_ayarkaydet;
        private System.Windows.Forms.Button Buton_ayariptal;
    }
}
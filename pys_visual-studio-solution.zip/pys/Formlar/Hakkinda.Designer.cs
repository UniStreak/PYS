﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class Hakkinda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hakkinda));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox_gnugpl = new System.Windows.Forms.PictureBox();
            this.label_hakkindapys = new System.Windows.Forms.Label();
            this.label_lisans = new System.Windows.Forms.Label();
            this.richTextBox_gnugpl = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_gnugpl)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button1.Location = new System.Drawing.Point(363, 525);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 34);
            this.button1.TabIndex = 0;
            this.button1.Text = "Tamam";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox_gnugpl
            // 
            this.pictureBox_gnugpl.Image = global::pys.Properties.Resources.gplv3;
            this.pictureBox_gnugpl.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_gnugpl.Name = "pictureBox_gnugpl";
            this.pictureBox_gnugpl.Size = new System.Drawing.Size(140, 78);
            this.pictureBox_gnugpl.TabIndex = 1;
            this.pictureBox_gnugpl.TabStop = false;
            // 
            // label_hakkindapys
            // 
            this.label_hakkindapys.AutoSize = true;
            this.label_hakkindapys.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label_hakkindapys.Location = new System.Drawing.Point(158, 12);
            this.label_hakkindapys.Name = "label_hakkindapys";
            this.label_hakkindapys.Size = new System.Drawing.Size(226, 21);
            this.label_hakkindapys.TabIndex = 2;
            this.label_hakkindapys.Text = "Personel Yönetim Sistemi - PYS";
            // 
            // label_lisans
            // 
            this.label_lisans.AutoSize = true;
            this.label_lisans.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label_lisans.Location = new System.Drawing.Point(158, 52);
            this.label_lisans.Name = "label_lisans";
            this.label_lisans.Size = new System.Drawing.Size(315, 38);
            this.label_lisans.TabIndex = 4;
            this.label_lisans.Text = "Personel Yönetim Sistemi ücretsiz bir yazılımdır, \r\nGNU GENERAL PUBLIC LICENSE il" +
    "e lisanslanmıştır.";
            // 
            // richTextBox_gnugpl
            // 
            this.richTextBox_gnugpl.Location = new System.Drawing.Point(12, 96);
            this.richTextBox_gnugpl.Name = "richTextBox_gnugpl";
            this.richTextBox_gnugpl.ReadOnly = true;
            this.richTextBox_gnugpl.Size = new System.Drawing.Size(461, 423);
            this.richTextBox_gnugpl.TabIndex = 5;
            this.richTextBox_gnugpl.Text = resources.GetString("richTextBox_gnugpl.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 525);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Copyright (C) 2019  Emre Aslan emreaslan_tr@hotmail.com";
            // 
            // Hakkinda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 566);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox_gnugpl);
            this.Controls.Add(this.label_lisans);
            this.Controls.Add(this.label_hakkindapys);
            this.Controls.Add(this.pictureBox_gnugpl);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Hakkinda";
            this.ShowInTaskbar = false;
            this.Text = "Personel Yönetim Sistemi Hakkında";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_gnugpl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox_gnugpl;
        private System.Windows.Forms.Label label_hakkindapys;
        private System.Windows.Forms.Label label_lisans;
        private System.Windows.Forms.RichTextBox richTextBox_gnugpl;
        private System.Windows.Forms.Label label1;
    }
}
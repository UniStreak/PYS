﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class OlayEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OlayEkle));
            this.errProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.Buton_iptal = new System.Windows.Forms.Button();
            this.Buton_olaykaydet = new System.Windows.Forms.Button();
            this.olayID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.grpBx_Details = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bitissaati = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.baslangicsaati = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.bitistarihi = new System.Windows.Forms.DateTimePicker();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.baslangictarihi = new System.Windows.Forms.DateTimePicker();
            this.olayaciklamasi = new System.Windows.Forms.TextBox();
            this.olayadi = new System.Windows.Forms.TextBox();
            this.lbl_Description = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).BeginInit();
            this.grpBx_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // errProvider
            // 
            this.errProvider.ContainerControl = this;
            // 
            // Buton_iptal
            // 
            this.Buton_iptal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_iptal.Location = new System.Drawing.Point(386, 261);
            this.Buton_iptal.Name = "Buton_iptal";
            this.Buton_iptal.Size = new System.Drawing.Size(83, 30);
            this.Buton_iptal.TabIndex = 8;
            this.Buton_iptal.Text = "İptal";
            this.Buton_iptal.UseVisualStyleBackColor = true;
            this.Buton_iptal.Click += new System.EventHandler(this.Buton_iptal_Click);
            // 
            // Buton_olaykaydet
            // 
            this.Buton_olaykaydet.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_olaykaydet.Location = new System.Drawing.Point(291, 261);
            this.Buton_olaykaydet.Name = "Buton_olaykaydet";
            this.Buton_olaykaydet.Size = new System.Drawing.Size(89, 30);
            this.Buton_olaykaydet.TabIndex = 7;
            this.Buton_olaykaydet.Text = "Kaydet";
            this.Buton_olaykaydet.UseVisualStyleBackColor = true;
            this.Buton_olaykaydet.Click += new System.EventHandler(this.Buton_olaykaydet_Click);
            // 
            // olayID
            // 
            this.olayID.Location = new System.Drawing.Point(388, 33);
            this.olayID.MaxLength = 10;
            this.olayID.Name = "olayID";
            this.olayID.Size = new System.Drawing.Size(59, 22);
            this.olayID.TabIndex = 1;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_ID.Location = new System.Drawing.Point(362, 33);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(20, 17);
            this.lbl_ID.TabIndex = 3;
            this.lbl_ID.Text = "ID";
            // 
            // grpBx_Details
            // 
            this.grpBx_Details.Controls.Add(this.label2);
            this.grpBx_Details.Controls.Add(this.bitissaati);
            this.grpBx_Details.Controls.Add(this.label3);
            this.grpBx_Details.Controls.Add(this.baslangicsaati);
            this.grpBx_Details.Controls.Add(this.label1);
            this.grpBx_Details.Controls.Add(this.bitistarihi);
            this.grpBx_Details.Controls.Add(this.lbl_Date);
            this.grpBx_Details.Controls.Add(this.baslangictarihi);
            this.grpBx_Details.Controls.Add(this.olayaciklamasi);
            this.grpBx_Details.Controls.Add(this.olayadi);
            this.grpBx_Details.Controls.Add(this.lbl_Description);
            this.grpBx_Details.Controls.Add(this.lbl_Name);
            this.grpBx_Details.Controls.Add(this.olayID);
            this.grpBx_Details.Controls.Add(this.lbl_ID);
            this.grpBx_Details.Location = new System.Drawing.Point(12, 12);
            this.grpBx_Details.Name = "grpBx_Details";
            this.grpBx_Details.Size = new System.Drawing.Size(457, 243);
            this.grpBx_Details.TabIndex = 4;
            this.grpBx_Details.TabStop = false;
            this.grpBx_Details.Text = "Olay Detayları";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(266, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Bitiş Saati";
            // 
            // bitissaati
            // 
            this.bitissaati.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bitissaati.Checked = false;
            this.bitissaati.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.bitissaati.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.bitissaati.Location = new System.Drawing.Point(335, 207);
            this.bitissaati.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.bitissaati.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.bitissaati.Name = "bitissaati";
            this.bitissaati.ShowCheckBox = true;
            this.bitissaati.ShowUpDown = true;
            this.bitissaati.Size = new System.Drawing.Size(112, 22);
            this.bitissaati.TabIndex = 6;
            this.bitissaati.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(235, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Başlangıç Saati";
            // 
            // baslangicsaati
            // 
            this.baslangicsaati.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslangicsaati.Checked = false;
            this.baslangicsaati.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.baslangicsaati.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.baslangicsaati.Location = new System.Drawing.Point(335, 179);
            this.baslangicsaati.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.baslangicsaati.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.baslangicsaati.Name = "baslangicsaati";
            this.baslangicsaati.ShowCheckBox = true;
            this.baslangicsaati.ShowUpDown = true;
            this.baslangicsaati.Size = new System.Drawing.Size(112, 22);
            this.baslangicsaati.TabIndex = 4;
            this.baslangicsaati.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(40, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Bitiş Tarihi";
            // 
            // bitistarihi
            // 
            this.bitistarihi.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bitistarihi.Checked = false;
            this.bitistarihi.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.bitistarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.bitistarihi.Location = new System.Drawing.Point(112, 207);
            this.bitistarihi.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.bitistarihi.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.bitistarihi.Name = "bitistarihi";
            this.bitistarihi.ShowCheckBox = true;
            this.bitistarihi.Size = new System.Drawing.Size(112, 22);
            this.bitistarihi.TabIndex = 5;
            this.bitistarihi.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Date.Location = new System.Drawing.Point(9, 183);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(97, 17);
            this.lbl_Date.TabIndex = 2;
            this.lbl_Date.Text = "Başlangıç Tarihi";
            // 
            // baslangictarihi
            // 
            this.baslangictarihi.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslangictarihi.Checked = false;
            this.baslangictarihi.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.baslangictarihi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.baslangictarihi.Location = new System.Drawing.Point(112, 179);
            this.baslangictarihi.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.baslangictarihi.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.baslangictarihi.Name = "baslangictarihi";
            this.baslangictarihi.ShowCheckBox = true;
            this.baslangictarihi.Size = new System.Drawing.Size(112, 22);
            this.baslangictarihi.TabIndex = 3;
            this.baslangictarihi.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            // 
            // olayaciklamasi
            // 
            this.olayaciklamasi.Location = new System.Drawing.Point(10, 85);
            this.olayaciklamasi.MaxLength = 10000;
            this.olayaciklamasi.Multiline = true;
            this.olayaciklamasi.Name = "olayaciklamasi";
            this.olayaciklamasi.Size = new System.Drawing.Size(437, 85);
            this.olayaciklamasi.TabIndex = 2;
            // 
            // olayadi
            // 
            this.olayadi.Location = new System.Drawing.Point(72, 33);
            this.olayadi.MaxLength = 200;
            this.olayadi.Name = "olayadi";
            this.olayadi.Size = new System.Drawing.Size(241, 22);
            this.olayadi.TabIndex = 0;
            // 
            // lbl_Description
            // 
            this.lbl_Description.AutoSize = true;
            this.lbl_Description.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Description.Location = new System.Drawing.Point(8, 65);
            this.lbl_Description.Name = "lbl_Description";
            this.lbl_Description.Size = new System.Drawing.Size(98, 17);
            this.lbl_Description.TabIndex = 5;
            this.lbl_Description.Text = "Olay Açıklaması";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Name.Location = new System.Drawing.Point(9, 33);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(57, 17);
            this.lbl_Name.TabIndex = 4;
            this.lbl_Name.Text = "Olay Adı";
            // 
            // OlayEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 298);
            this.Controls.Add(this.grpBx_Details);
            this.Controls.Add(this.Buton_olaykaydet);
            this.Controls.Add(this.Buton_iptal);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "OlayEkle";
            this.Text = "Olaylar";
            ((System.ComponentModel.ISupportInitialize)(this.errProvider)).EndInit();
            this.grpBx_Details.ResumeLayout(false);
            this.grpBx_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errProvider;
        private System.Windows.Forms.Button Buton_olaykaydet;
        private System.Windows.Forms.Button Buton_iptal;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.GroupBox grpBx_Details;
        private System.Windows.Forms.TextBox olayaciklamasi;
        private System.Windows.Forms.TextBox olayadi;
        private System.Windows.Forms.Label lbl_Description;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.TextBox olayID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.DateTimePicker baslangictarihi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker bitistarihi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker bitissaati;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker baslangicsaati;
    }
}
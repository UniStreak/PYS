﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

namespace pys
{
    partial class PuantajDuzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PuantajDuzenle));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton_resmitatil = new System.Windows.Forms.RadioButton();
            this.radioButton_ucretli = new System.Windows.Forms.RadioButton();
            this.radioButton_ucretsiz = new System.Windows.Forms.RadioButton();
            this.radioButton_s_mazeret = new System.Windows.Forms.RadioButton();
            this.radioButton_g_mazeret = new System.Windows.Forms.RadioButton();
            this.radioButton_raporlu = new System.Windows.Forms.RadioButton();
            this.radioButton_yillik_izin = new System.Windows.Forms.RadioButton();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txt_saat = new System.Windows.Forms.DateTimePicker();
            this.txt_gun = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_cikistarihi = new System.Windows.Forms.TextBox();
            this.txt_giristarihi = new System.Windows.Forms.TextBox();
            this.txt_departman = new System.Windows.Forms.TextBox();
            this.txt_pozisyon = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_soyadi = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_adi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_tc = new System.Windows.Forms.TextBox();
            this.Buton_iptal = new System.Windows.Forms.Button();
            this.Buton_kaydet = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton_resmitatil);
            this.groupBox2.Controls.Add(this.radioButton_ucretli);
            this.groupBox2.Controls.Add(this.radioButton_ucretsiz);
            this.groupBox2.Controls.Add(this.radioButton_s_mazeret);
            this.groupBox2.Controls.Add(this.radioButton_g_mazeret);
            this.groupBox2.Controls.Add(this.radioButton_raporlu);
            this.groupBox2.Controls.Add(this.radioButton_yillik_izin);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.txt_saat);
            this.groupBox2.Controls.Add(this.txt_gun);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(12, 168);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(695, 127);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Puantaj Bilgileri";
            // 
            // radioButton_resmitatil
            // 
            this.radioButton_resmitatil.AutoSize = true;
            this.radioButton_resmitatil.Enabled = false;
            this.radioButton_resmitatil.Location = new System.Drawing.Point(208, 93);
            this.radioButton_resmitatil.Name = "radioButton_resmitatil";
            this.radioButton_resmitatil.Size = new System.Drawing.Size(14, 13);
            this.radioButton_resmitatil.TabIndex = 48;
            this.radioButton_resmitatil.TabStop = true;
            this.radioButton_resmitatil.UseVisualStyleBackColor = true;
            this.radioButton_resmitatil.CheckedChanged += new System.EventHandler(this.radioButton_resmitatil_CheckedChanged);
            // 
            // radioButton_ucretli
            // 
            this.radioButton_ucretli.AutoSize = true;
            this.radioButton_ucretli.Enabled = false;
            this.radioButton_ucretli.Location = new System.Drawing.Point(541, 64);
            this.radioButton_ucretli.Name = "radioButton_ucretli";
            this.radioButton_ucretli.Size = new System.Drawing.Size(14, 13);
            this.radioButton_ucretli.TabIndex = 47;
            this.radioButton_ucretli.TabStop = true;
            this.radioButton_ucretli.UseVisualStyleBackColor = true;
            this.radioButton_ucretli.CheckedChanged += new System.EventHandler(this.radioButton_ucretli_CheckedChanged);
            // 
            // radioButton_ucretsiz
            // 
            this.radioButton_ucretsiz.AutoSize = true;
            this.radioButton_ucretsiz.Enabled = false;
            this.radioButton_ucretsiz.Location = new System.Drawing.Point(541, 35);
            this.radioButton_ucretsiz.Name = "radioButton_ucretsiz";
            this.radioButton_ucretsiz.Size = new System.Drawing.Size(14, 13);
            this.radioButton_ucretsiz.TabIndex = 46;
            this.radioButton_ucretsiz.TabStop = true;
            this.radioButton_ucretsiz.UseVisualStyleBackColor = true;
            this.radioButton_ucretsiz.CheckedChanged += new System.EventHandler(this.radioButton_ucretsiz_CheckedChanged);
            // 
            // radioButton_s_mazeret
            // 
            this.radioButton_s_mazeret.AutoSize = true;
            this.radioButton_s_mazeret.Enabled = false;
            this.radioButton_s_mazeret.Location = new System.Drawing.Point(344, 64);
            this.radioButton_s_mazeret.Name = "radioButton_s_mazeret";
            this.radioButton_s_mazeret.Size = new System.Drawing.Size(14, 13);
            this.radioButton_s_mazeret.TabIndex = 45;
            this.radioButton_s_mazeret.TabStop = true;
            this.radioButton_s_mazeret.UseVisualStyleBackColor = true;
            this.radioButton_s_mazeret.CheckedChanged += new System.EventHandler(this.radioButton_s_mazeret_CheckedChanged);
            // 
            // radioButton_g_mazeret
            // 
            this.radioButton_g_mazeret.AutoSize = true;
            this.radioButton_g_mazeret.Enabled = false;
            this.radioButton_g_mazeret.Location = new System.Drawing.Point(344, 35);
            this.radioButton_g_mazeret.Name = "radioButton_g_mazeret";
            this.radioButton_g_mazeret.Size = new System.Drawing.Size(14, 13);
            this.radioButton_g_mazeret.TabIndex = 44;
            this.radioButton_g_mazeret.TabStop = true;
            this.radioButton_g_mazeret.UseVisualStyleBackColor = true;
            this.radioButton_g_mazeret.CheckedChanged += new System.EventHandler(this.radioButton_g_mazeret_CheckedChanged);
            // 
            // radioButton_raporlu
            // 
            this.radioButton_raporlu.AutoSize = true;
            this.radioButton_raporlu.Enabled = false;
            this.radioButton_raporlu.Location = new System.Drawing.Point(208, 64);
            this.radioButton_raporlu.Name = "radioButton_raporlu";
            this.radioButton_raporlu.Size = new System.Drawing.Size(14, 13);
            this.radioButton_raporlu.TabIndex = 43;
            this.radioButton_raporlu.TabStop = true;
            this.radioButton_raporlu.UseVisualStyleBackColor = true;
            this.radioButton_raporlu.CheckedChanged += new System.EventHandler(this.radioButton_raporlu_CheckedChanged);
            // 
            // radioButton_yillik_izin
            // 
            this.radioButton_yillik_izin.AutoSize = true;
            this.radioButton_yillik_izin.Enabled = false;
            this.radioButton_yillik_izin.Location = new System.Drawing.Point(208, 35);
            this.radioButton_yillik_izin.Name = "radioButton_yillik_izin";
            this.radioButton_yillik_izin.Size = new System.Drawing.Size(14, 13);
            this.radioButton_yillik_izin.TabIndex = 42;
            this.radioButton_yillik_izin.TabStop = true;
            this.radioButton_yillik_izin.UseVisualStyleBackColor = true;
            this.radioButton_yillik_izin.CheckedChanged += new System.EventHandler(this.radioButton_yillik_izin_CheckedChanged);
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.SkyBlue;
            this.textBox7.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox7.Location = new System.Drawing.Point(228, 89);
            this.textBox7.MaxLength = 100;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(444, 23);
            this.textBox7.TabIndex = 41;
            this.textBox7.Text = "Resmi Tatil";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.PaleGreen;
            this.textBox6.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox6.Location = new System.Drawing.Point(561, 60);
            this.textBox6.MaxLength = 100;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(111, 23);
            this.textBox6.TabIndex = 40;
            this.textBox6.Text = "Ücretli İzin";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Orchid;
            this.textBox5.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox5.Location = new System.Drawing.Point(561, 31);
            this.textBox5.MaxLength = 100;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(111, 23);
            this.textBox5.TabIndex = 39;
            this.textBox5.Text = "Ücretsiz İzin";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox4.Location = new System.Drawing.Point(228, 60);
            this.textBox4.MaxLength = 100;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(100, 23);
            this.textBox4.TabIndex = 38;
            this.textBox4.Text = "Raporlu";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.MediumTurquoise;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox3.Location = new System.Drawing.Point(364, 60);
            this.textBox3.MaxLength = 100;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(160, 23);
            this.textBox3.TabIndex = 37;
            this.textBox3.Text = "Saatlik Mazeret İzni";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Salmon;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox2.Location = new System.Drawing.Point(364, 31);
            this.textBox2.MaxLength = 100;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(160, 23);
            this.textBox2.TabIndex = 36;
            this.textBox2.Text = "Günlük Mazeret İzni";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.YellowGreen;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBox1.Location = new System.Drawing.Point(228, 31);
            this.textBox1.MaxLength = 100;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 35;
            this.textBox1.Text = "Yıllık İzin";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_saat
            // 
            this.txt_saat.CustomFormat = "HH\':\'mm";
            this.txt_saat.Enabled = false;
            this.txt_saat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_saat.Location = new System.Drawing.Point(104, 80);
            this.txt_saat.Name = "txt_saat";
            this.txt_saat.ShowUpDown = true;
            this.txt_saat.Size = new System.Drawing.Size(55, 23);
            this.txt_saat.TabIndex = 34;
            this.txt_saat.Value = new System.DateTime(2019, 2, 23, 0, 0, 0, 0);
            // 
            // txt_gun
            // 
            this.txt_gun.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_gun.FormattingEnabled = true;
            this.txt_gun.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.txt_gun.Location = new System.Drawing.Point(104, 42);
            this.txt_gun.Name = "txt_gun";
            this.txt_gun.Size = new System.Drawing.Size(55, 23);
            this.txt_gun.TabIndex = 31;
            this.txt_gun.SelectionChangeCommitted += new System.EventHandler(this.txt_gun_SelectionChangeCommitted);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label8.Location = new System.Drawing.Point(32, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 19);
            this.label8.TabIndex = 27;
            this.label8.Text = "İzin Saati:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label7.Location = new System.Drawing.Point(7, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 19);
            this.label7.TabIndex = 26;
            this.label7.Text = "Takvim Günü:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_cikistarihi);
            this.groupBox1.Controls.Add(this.txt_giristarihi);
            this.groupBox1.Controls.Add(this.txt_departman);
            this.groupBox1.Controls.Add(this.txt_pozisyon);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_soyadi);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.txt_adi);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_tc);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(695, 150);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personel Bilgileri";
            // 
            // txt_cikistarihi
            // 
            this.txt_cikistarihi.BackColor = System.Drawing.SystemColors.Window;
            this.txt_cikistarihi.Enabled = false;
            this.txt_cikistarihi.Location = new System.Drawing.Point(376, 116);
            this.txt_cikistarihi.MaxLength = 30;
            this.txt_cikistarihi.Name = "txt_cikistarihi";
            this.txt_cikistarihi.ReadOnly = true;
            this.txt_cikistarihi.Size = new System.Drawing.Size(146, 23);
            this.txt_cikistarihi.TabIndex = 25;
            // 
            // txt_giristarihi
            // 
            this.txt_giristarihi.BackColor = System.Drawing.SystemColors.Window;
            this.txt_giristarihi.Enabled = false;
            this.txt_giristarihi.Location = new System.Drawing.Point(104, 116);
            this.txt_giristarihi.MaxLength = 30;
            this.txt_giristarihi.Name = "txt_giristarihi";
            this.txt_giristarihi.ReadOnly = true;
            this.txt_giristarihi.Size = new System.Drawing.Size(182, 23);
            this.txt_giristarihi.TabIndex = 24;
            // 
            // txt_departman
            // 
            this.txt_departman.BackColor = System.Drawing.SystemColors.Window;
            this.txt_departman.Enabled = false;
            this.txt_departman.Location = new System.Drawing.Point(376, 58);
            this.txt_departman.MaxLength = 20;
            this.txt_departman.Name = "txt_departman";
            this.txt_departman.ReadOnly = true;
            this.txt_departman.Size = new System.Drawing.Size(146, 23);
            this.txt_departman.TabIndex = 14;
            // 
            // txt_pozisyon
            // 
            this.txt_pozisyon.BackColor = System.Drawing.SystemColors.Window;
            this.txt_pozisyon.Enabled = false;
            this.txt_pozisyon.Location = new System.Drawing.Point(376, 87);
            this.txt_pozisyon.MaxLength = 30;
            this.txt_pozisyon.Name = "txt_pozisyon";
            this.txt_pozisyon.ReadOnly = true;
            this.txt_pozisyon.Size = new System.Drawing.Size(146, 23);
            this.txt_pozisyon.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label15.Location = new System.Drawing.Point(49, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 19);
            this.label15.TabIndex = 23;
            this.label15.Text = "Soyadı";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label5.Location = new System.Drawing.Point(292, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 19);
            this.label5.TabIndex = 13;
            this.label5.Text = "Departman";
            // 
            // txt_soyadi
            // 
            this.txt_soyadi.BackColor = System.Drawing.SystemColors.Window;
            this.txt_soyadi.Enabled = false;
            this.txt_soyadi.Location = new System.Drawing.Point(104, 87);
            this.txt_soyadi.MaxLength = 30;
            this.txt_soyadi.Name = "txt_soyadi";
            this.txt_soyadi.ReadOnly = true;
            this.txt_soyadi.Size = new System.Drawing.Size(182, 23);
            this.txt_soyadi.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label11.Location = new System.Drawing.Point(298, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 19);
            this.label11.TabIndex = 17;
            this.label11.Text = "Çıkış Tarihi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(543, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(146, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label9.Location = new System.Drawing.Point(27, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 19);
            this.label9.TabIndex = 16;
            this.label9.Text = "Giriş Tarihi";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label14.Location = new System.Drawing.Point(347, 30);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 19);
            this.label14.TabIndex = 17;
            this.label14.Text = "ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(308, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 19);
            this.label1.TabIndex = 12;
            this.label1.Text = "Pozisyon";
            // 
            // txt_id
            // 
            this.txt_id.BackColor = System.Drawing.SystemColors.Window;
            this.txt_id.Enabled = false;
            this.txt_id.Location = new System.Drawing.Point(376, 29);
            this.txt_id.MaxLength = 10;
            this.txt_id.Name = "txt_id";
            this.txt_id.ReadOnly = true;
            this.txt_id.Size = new System.Drawing.Size(146, 23);
            this.txt_id.TabIndex = 12;
            // 
            // txt_adi
            // 
            this.txt_adi.BackColor = System.Drawing.SystemColors.Window;
            this.txt_adi.Enabled = false;
            this.txt_adi.Location = new System.Drawing.Point(104, 58);
            this.txt_adi.MaxLength = 30;
            this.txt_adi.Name = "txt_adi";
            this.txt_adi.ReadOnly = true;
            this.txt_adi.Size = new System.Drawing.Size(182, 23);
            this.txt_adi.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(12, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "TC Kimlik No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label3.Location = new System.Drawing.Point(69, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adı";
            // 
            // txt_tc
            // 
            this.txt_tc.BackColor = System.Drawing.SystemColors.Window;
            this.txt_tc.Enabled = false;
            this.txt_tc.Location = new System.Drawing.Point(104, 29);
            this.txt_tc.MaxLength = 11;
            this.txt_tc.Name = "txt_tc";
            this.txt_tc.ReadOnly = true;
            this.txt_tc.Size = new System.Drawing.Size(182, 23);
            this.txt_tc.TabIndex = 1;
            // 
            // Buton_iptal
            // 
            this.Buton_iptal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_iptal.Location = new System.Drawing.Point(603, 301);
            this.Buton_iptal.Name = "Buton_iptal";
            this.Buton_iptal.Size = new System.Drawing.Size(105, 35);
            this.Buton_iptal.TabIndex = 17;
            this.Buton_iptal.Text = "İptal";
            this.Buton_iptal.UseVisualStyleBackColor = true;
            this.Buton_iptal.Click += new System.EventHandler(this.Buton_iptal_Click);
            // 
            // Buton_kaydet
            // 
            this.Buton_kaydet.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Buton_kaydet.Location = new System.Drawing.Point(492, 301);
            this.Buton_kaydet.Name = "Buton_kaydet";
            this.Buton_kaydet.Size = new System.Drawing.Size(105, 35);
            this.Buton_kaydet.TabIndex = 16;
            this.Buton_kaydet.Text = "Kaydet";
            this.Buton_kaydet.UseVisualStyleBackColor = true;
            this.Buton_kaydet.Click += new System.EventHandler(this.Buton_kaydet_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // PuantajDuzenle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 343);
            this.Controls.Add(this.Buton_iptal);
            this.Controls.Add(this.Buton_kaydet);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PuantajDuzenle";
            this.Text = "Puantaj Kaydı";
            this.Shown += new System.EventHandler(this.PuantajDuzenle_Shown);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_soyadi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_adi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_tc;
        private System.Windows.Forms.TextBox txt_cikistarihi;
        private System.Windows.Forms.TextBox txt_giristarihi;
        private System.Windows.Forms.TextBox txt_departman;
        private System.Windows.Forms.TextBox txt_pozisyon;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Buton_iptal;
        private System.Windows.Forms.Button Buton_kaydet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox txt_gun;
        private System.Windows.Forms.DateTimePicker txt_saat;
        private System.Windows.Forms.RadioButton radioButton_resmitatil;
        private System.Windows.Forms.RadioButton radioButton_ucretli;
        private System.Windows.Forms.RadioButton radioButton_ucretsiz;
        private System.Windows.Forms.RadioButton radioButton_s_mazeret;
        private System.Windows.Forms.RadioButton radioButton_g_mazeret;
        private System.Windows.Forms.RadioButton radioButton_raporlu;
        private System.Windows.Forms.RadioButton radioButton_yillik_izin;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}
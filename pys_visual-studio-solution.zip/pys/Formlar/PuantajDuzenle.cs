﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Windows.Forms;
using pys.Personel;
using pys.Diger;

namespace pys
{
    public partial class PuantajDuzenle : Form
    {
        int calisanID;
        public Calisan _Calisan { get; private set; }
        string _yil;
        string _ay;
        string _gun;
        string _sablon;
        string PuantajID;
        PuantajKaydi puantajKaydi;

        public PuantajDuzenle(Calisan calisan, string yil, string ay)
        {
            InitializeComponent();
            _Calisan = calisan;
            calisanID = _Calisan.CalisanID;
            _yil = yil;
            _ay = ay;
            txt_id.Text = $"{calisanID:D7}";
            txt_tc.Text = _Calisan._CalisanKayit.TC_Kimlik;
            txt_adi.Text = _Calisan._CalisanKayit.Adi;
            txt_soyadi.Text = _Calisan._CalisanKayit.Soyadi;
            txt_departman.Text = _Calisan._CalisanKayit.Departman;
            txt_pozisyon.Text = _Calisan._CalisanKayit.Pozisyon;
            txt_giristarihi.Text = _Calisan._CalisanKayit.GirisT;
            if (_Calisan._CalisanKayit.CikisTCheck)            
                txt_cikistarihi.Text = _Calisan._CalisanKayit.CikisT;            
            else
                txt_cikistarihi.Text = "-";
            pictureBox1.ImageLocation = _Calisan._CalisanKayit.FotoYolu;
            groupBox2.Text+= $": {ay} {yil}";            
        }

        private void txt_gun_SelectionChangeCommitted(object sender, EventArgs e)
        {
            _gun = txt_gun.Text;
            PuantajID = _yil + _ay + _gun;
            radioButton_yillik_izin.Enabled = true; 
            radioButton_g_mazeret.Enabled = true;
            radioButton_s_mazeret.Enabled = true;
            radioButton_raporlu.Enabled = true;
            radioButton_ucretsiz.Enabled = true;
            radioButton_ucretli.Enabled = true;
            radioButton_resmitatil.Enabled = true;
            toolTip1.IsBalloon = false;
            toolTip1.ToolTipTitle = _gun+ " " +_ay + " " + _yil;
            toolTip1.Show("Gün seçildi, lütfen izin şablonu seçin.", textBox1, 103, -40, 3000);
            if (_Calisan.PuantajKayitlari._PuantajKayitlari.ContainsKey(PuantajID))
            {
                txt_saat.Enabled = true;
                txt_saat.Text = _Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Saat;
                if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "yi")
                    radioButton_yillik_izin.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "gmi")
                    radioButton_g_mazeret.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "smi")
                    radioButton_s_mazeret.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "rp")
                    radioButton_raporlu.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "usiz")
                    radioButton_ucretsiz.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "uli")
                    radioButton_ucretli.Checked = true;
                else if (_Calisan.PuantajKayitlari._PuantajKayitlari[PuantajID].Sablon == "rt")
                    radioButton_resmitatil.Checked = true;
            }
        }

        private void radioButton_yillik_izin_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_yillik_izin.Checked)
                _sablon = "yi";
            txt_saat.Enabled = true;
        }

        private void radioButton_g_mazeret_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_g_mazeret.Checked)
                _sablon = "gmi";
            txt_saat.Enabled = true;
        }

        private void radioButton_s_mazeret_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_s_mazeret.Checked)
                _sablon = "smi";
            txt_saat.Enabled = true;
        }

        private void radioButton_raporlu_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_raporlu.Checked)
                _sablon = "rp";
            txt_saat.Enabled = true;
        }

        private void radioButton_ucretsiz_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_ucretsiz.Checked)
                _sablon = "usiz";
            txt_saat.Enabled = true;
        }

        private void radioButton_ucretli_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_ucretli.Checked)
                _sablon = "uli";
            txt_saat.Enabled = true;
        }

        private void radioButton_resmitatil_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_resmitatil.Checked)
                _sablon = "rt";
            txt_saat.Enabled = true;
        }

        private void Buton_kaydet_Click(object sender, EventArgs e)
        {
            if (!((radioButton_yillik_izin.Checked)||
                (radioButton_g_mazeret.Checked)||
                (radioButton_s_mazeret.Checked)||
                (radioButton_raporlu.Checked)||
                (radioButton_ucretsiz.Checked)||
                (radioButton_ucretli.Checked)||
                (radioButton_resmitatil.Checked)))
            {
                MessageBox.Show(Strings.Errors.NOT_SELECTED, Strings.Errors.ERROR_TITLE);
                return;
            }
            puantajKaydi = new PuantajKaydi(_sablon, _gun, _ay, _yil, txt_saat.Text);
            if (_Calisan.PuantajKayitlari._PuantajKayitlari.ContainsKey(PuantajID))
            {
                _Calisan.PuantajKayitlari._PuantajKayitlari.Remove(PuantajID);
            }
            _Calisan.PuantajKayitlari._PuantajKayitlari.Add(PuantajID, puantajKaydi);
            DialogResult = DialogResult.OK;
            Close();
        }

        private void Buton_iptal_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void PuantajDuzenle_Shown(object sender, EventArgs e)
        {
            toolTip1.ToolTipTitle = _ay+" "+_yil;
            toolTip1.Show("Puantaj ayarlamak için takvim günü seçin.", txt_gun,10,-75,3000);
        }
    }
}

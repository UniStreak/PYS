﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.Windows.Forms;
using pys.Personel;
using pys.Diger;
using System.Collections;
using System.Drawing;

namespace pys
{
    public partial class PuantajEkrani : Form
    {
        public DBfunctions<uint, Calisan> pdatafile;
        public string PuantajID;
        public PuantajEkrani(DBfunctions<uint, Calisan> _pdatafile)
        {
            InitializeComponent();
            pdatafile = _pdatafile;
            listView_puantaj.Sort();
            listView_puantaj.ListViewItemSorter = new SayiSirala(0, listView_puantaj.Sorting);
        }

        private void AddItem(Calisan emp)
        {
            if (emp == null) throw new ArgumentNullException(Strings.Errors.INVALID_OBJECT);

            ListViewItem lvi = new ListViewItem($"{emp.CalisanID}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Adi}");
            lvi.SubItems.Add($"{emp._CalisanKayit.Soyadi}");
            for (int x = 1; x <= 31; x++)
            {
                if (emp.PuantajKayitlari._PuantajKayitlari.ContainsKey(PuantajID + x.ToString()))
                {
                    lvi.UseItemStyleForSubItems = false;
                    lvi.SubItems.Add($"{emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Saat}");
                    if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "yi")                    
                       lvi.SubItems[x+2].BackColor = Color.YellowGreen;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "gmi")
                        lvi.SubItems[x + 2].BackColor = Color.Salmon;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "smi")
                        lvi.SubItems[x + 2].BackColor = Color.MediumTurquoise;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "rp")
                        lvi.SubItems[x + 2].BackColor = Color.LightSteelBlue;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "usiz")
                        lvi.SubItems[x + 2].BackColor = Color.Orchid;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "uli")
                        lvi.SubItems[x + 2].BackColor = Color.PaleGreen;
                    else if (emp.PuantajKayitlari._PuantajKayitlari[PuantajID + x.ToString()].Sablon == "rt")
                        lvi.SubItems[x + 2].BackColor = Color.SkyBlue;
                }                    
                else
                    lvi.SubItems.Add($"00:00");
            }
            int toplamsaat = 0;
            int toplamdakika = 0;
            for (int x = 3; x <= 33; x++)
            {
                toplamdakika += Convert.ToInt32(lvi.SubItems[x].Text.Substring(3,2));
                toplamsaat+= Convert.ToInt32(lvi.SubItems[x].Text.Substring(0, 2));
            }
            toplamsaat += (toplamdakika / 60);
            toplamdakika = toplamdakika % 60;
            string toplamsaatstr = toplamsaat.ToString();
            string toplamdakikastr = toplamdakika.ToString();
            if (toplamsaatstr.Length == 1)
                toplamsaatstr = "0" + toplamsaatstr;
            if (toplamdakikastr.Length == 1)
                toplamdakikastr = "0" + toplamdakikastr;
            string toplam = toplamsaatstr + ":" + toplamdakikastr;
            lvi.SubItems.Add($"{toplam}");
            listView_puantaj.Items.Add(lvi);
        }

        private void DisplayDatabase()
        {

            if (listView_puantaj.Items.Count > 0)
                listView_puantaj.Items.Clear();
            listView_puantaj.BeginUpdate();
            foreach (var emp in pdatafile.Database.Values)
            {
                if (emp.IsVisible)
                {
                    AddItem(emp);
                }

            }
            listView_puantaj.EndUpdate();
        }

        private void cb_yil_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cb_ay.Enabled = true;
            if (cb_ay.Text != "")
            {
                PuantajID = cb_yil.Text + cb_ay.Text;
                DisplayDatabase();
            }
                
        }

        private void cb_ay_SelectionChangeCommitted(object sender, EventArgs e)
        {
            PuantajID = cb_yil.Text + cb_ay.Text;
            DisplayDatabase();
        }

        private void listView_puantaj_DoubleClick(object sender, EventArgs e)
        {
            Buton_puantajduzenle_Click(sender, e);
        }

        private void Buton_puantajduzenle_Click(object sender, EventArgs e)
        {
            if (listView_puantaj.SelectedItems.Count == 0)
            {
                MessageBox.Show(Strings.Errors.NO_RECORDS_SELECTED,
                    Strings.Errors.ERROR_TITLE,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            uint id = uint.Parse(listView_puantaj.SelectedItems[0].Text);          
            using (PuantajDuzenle form = new PuantajDuzenle(pdatafile.Retrieve(id), cb_yil.Text, cb_ay.Text))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    pdatafile.Remove(id);
                    pdatafile.Add((uint)form._Calisan.CalisanID, form._Calisan);
                    listView_puantaj.SelectedItems[0].Remove();
                    AddItem(form._Calisan);                    
                }
            }


        }

        public class SayiSirala : IComparer
        {

            private int col;
            private SortOrder order;
            public SayiSirala()
            {
                col = 0;
                order = SortOrder.Ascending;
            }
            public SayiSirala(int column, SortOrder order)
            {
                col = column;
                this.order = order;
            }
            public int Compare(object x, object y)
            {
                int returnVal = -1;
                int intx = 0, inty = 0;
                if (!Int32.TryParse(((ListViewItem)x).SubItems[col].Text, out intx)) intx = 0;
                if (!Int32.TryParse(((ListViewItem)y).SubItems[col].Text, out inty)) inty = 0;
                returnVal = intx.CompareTo(inty);

                if (order == SortOrder.Descending) returnVal *= -1;
                return returnVal;
            }
        }
    }
}

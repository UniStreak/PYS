﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System.Collections.Generic;
using System.Runtime.Serialization;

namespace pys.Personel
{

    [DataContract,
        KnownType(typeof(CalisanNesne))]
    public abstract class Calisan
    {
        [DataMember(IsRequired = true)] public CalisanKayit _CalisanKayit;
        [DataMember(Name = "CalisanID", IsRequired = true)] public int CalisanID { get; set; }
        [DataMember(Name = "Visible")] public bool IsVisible { get; set; }
        [DataMember] public PersonelOlaylari _PersonelOlaylari;
        [DataMember] public PuantajKayitlari PuantajKayitlari;

        public Calisan()
        {
            _CalisanKayit = new CalisanKayit();
            CalisanID = -1;
            _PersonelOlaylari = new PersonelOlaylari
            {
                Olaylar = new SortedDictionary<string, Olay>()
            };
            PuantajKayitlari = new PuantajKayitlari
            {
                _PuantajKayitlari = new SortedDictionary<string, PuantajKaydi>()
            };
            IsVisible = true;
        }

        public Calisan(CalisanKayit calisanKayit, int _calisanID)
        {
            _CalisanKayit = calisanKayit;
            CalisanID = _calisanID;
            _PersonelOlaylari = new PersonelOlaylari
            {
                Olaylar = new SortedDictionary<string, Olay>()
            };
            PuantajKayitlari = new PuantajKayitlari
            {
                _PuantajKayitlari = new SortedDictionary<string, PuantajKaydi>()
            };
            IsVisible = true;
        }


    }
}
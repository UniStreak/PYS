﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System.Collections.Generic;
using System.Runtime.Serialization;

namespace pys.Personel
{
    [DataContract(Name = "Puantaj")]
    public struct PuantajKayitlari
    {
        [DataMember] public SortedDictionary<string, PuantajKaydi> _PuantajKayitlari;
    }

    [DataContract]
    public struct PuantajKaydi
    {
        [DataMember(Name = "Sablon", IsRequired = true)] public string Sablon { get; set; }
        [DataMember(Name = "Gun", IsRequired = true)] public string Gun { get; set; }
        [DataMember(Name = "Ay", IsRequired = true)] public string Ay { get; set; }
        [DataMember(Name = "Yil", IsRequired = true)] public string Yil { get; set; }
        [DataMember(Name = "Saat", IsRequired = true)] public string Saat { get; set; }
        [DataMember] public string PID { get; set; }


        public PuantajKaydi(string Sablon_, string Gun_, string Ay_, string Yil_, string Saat_)
        {
            PID = Yil_ + Ay_ + Gun_;
            Sablon = Sablon_;
            Gun = Gun_;
            Ay = Ay_;
            Yil = Yil_;
            Saat = Saat_;
        }
    }
}
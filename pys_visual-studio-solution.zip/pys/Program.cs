﻿// Personel Yönetim Sistemi - PYS
// -------------------------------------------------
// -------------------------------------------------
// Copyright(C) 2019  Emre Aslan
//
// Personel Yönetim Sistemi ücretsiz bir yazılımdır,
// GNU GENERAL PUBLIC LICENSE ile lisanslanmıştır.
// -------------------------------------------------

using System;
using System.IO;
using System.Windows.Forms;
using pys.Diger;

namespace pys
{
    static class Program
    {
        /// <summary>
        /// Uygulamanın ana girdi noktası.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && !string.IsNullOrEmpty(args[0]))
            {                
                if (System.IO.File.Exists(args[0]))
                {
                    StartApplication(args[0]);
                }
                else
                {                    
                    MessageBox.Show(Strings.Errors.INVALID_FILENAME, Strings.Errors.ERROR_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error);                    
                    Application.Run(new AnaEkran());
                }
            }
            
            else if (!string.IsNullOrEmpty(Properties.Settings.Default.DB_Yolu))
            {
                if (System.IO.File.Exists(Properties.Settings.Default.DB_Yolu))
                {
                    StartApplication(Properties.Settings.Default.DB_Yolu);
                }
                else
                {                   
                    MessageBox.Show(Strings.Errors.FIRST_TIME_USING, Strings.Errors.INFO_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    File.WriteAllBytes(@".\personel.pysdb", Properties.Resources.personel);
                    StartApplication(Properties.Settings.Default.DB_Yolu);
                }
            }
            else
            {
                
                Application.Run(new AnaEkran());
            }
        }

        static void StartApplication(string fileName)
        {
            AnaEkran form = new AnaEkran();
            form.ImportData(fileName);
            Application.Run(form);
        }
        
    }
    
}
